<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id_sede = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $nome_user = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/form_feed.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <main>
            <div id="logo">
                <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
            </div>
            <div id="resto">
                <div id="pesquisa">
                    <input type="text" placeholder="Pesquisar...">
                </div>
                <div id="user">
                <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                    </div>
                    <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                        <span><?php echo $nome_user; ?></span>
                    </div>
                </div>
            </div>
        </main>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <a href="./materias.php">matérias da sede</a>
        <a href="./form_solic.html">fazer solicitação</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="postagemt">
            <h2>Escreva sua postagem:</h2>
        </div>
        <form method="POST" action="./server_scripts/processa_formfeed.php" enctype="multipart/form-data" id="postagem">
            <div id="titulo_texto">
                    <h3>título:</h3>
                <input type="text" name="titulo" placeholder="Título..." id="tituloe"><br>
                    <h3>texto:</h3>
                <textarea id="textoe" name="texto" ></textarea><br>
            </div>
            <div id="aditivos">
                <input type="file" name="file" id="img"><br>
            </div>
            <h5 id="res_text"></h5>
            <input type="button" id="enviar" onclick="postar_feed()" value="postar">
        </form>
    </div>
</body>
<script src="./javascripts/form_posts.js"></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

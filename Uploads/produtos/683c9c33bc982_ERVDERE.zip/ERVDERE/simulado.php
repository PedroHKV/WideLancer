<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    include "./server_scripts/modulos/mod2_inserts.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $funcao = cargo( $sql , $id , $user);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['assuntos']) && !empty($_POST['assuntos'])) {
            $assuntos = $_POST['assuntos'];
            if (isset($_POST['num']) && $_POST['num'] !== "NaN"){
                $num = $_POST['num'];
                $questoes = select_questoes($sql , $assuntos , $num);
            } 
        } else {
            header("Location: http://localhost/ERVDERE/filtro_simulado.php");
        }
    }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/simulado.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                <div id="usuario">
                    <img src="./imagens/amigo.png" alt="Foto do usuário">
                    <span>Usuário</span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
    <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <?php
            if ( $funcao === "Curador"){
                echo "<a href='./caixa_solic.html'>solicitações</a>";
            }
        ?>

        <a href="./form_solic.html">fazer solicitação</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="simuladon">
            <h2>Simulado</h2>
        </div>
        <div id="simulado">
            <div id="cronometroquestao">
                    <?php
                        foreach ($questoes as $questao) {
                            echo "<div class='questao'>
                                    <div class='imageme'>
                                        <img src=".$questao[1].">
                                    </div><br><br>
                                    <div class='enunciado'>
                                        <h5>
                                            ".$questao[2]."
                                        </h5>
                                    </div><br><br>
                                    <div id='respostas'>  
                                        <input type='radio' id='' class='opcao1' name='resposta".$questao[5]."' value='".$questao[3][0]."'>
                                        <label for='opcao1'> ".$questao[3][0]."</label><br>

                                        <input type='radio' class='opcao1' name='resposta".$questao[5]."' value='".$questao[3][1]."'>
                                        <label for='opcao1'> ".$questao[3][1]."</label><br>
                            
                                        <input type='radio' class='opcao1' name='resposta".$questao[5]."' value='".$questao[3][2]."'>
                                        <label for='opcao1'> ".$questao[3][2]."</label><br>

                                        <input type='radio' class='opcao1' name='resposta".$questao[5]."' value='".$questao[3][3]."'>
                                        <label for='opcao1'> ".$questao[3][3]."</label><br>
                                        
                                        <input type='radio' class='opcao1' name='resposta".$questao[5]."' value='".$questao[3][4]."'>
                                        <label for='opcao1'> ".$questao[3][4]."</label><br>

                                    </div>
                                </div><br><br>";
                        }
                    ?>
            </div>
            <div id="foot">
                <div id="tempo">00:00:00</div>
                <div id="enviarsimulado">
                    <button onclick="enviar()" id="enviarresps">Enviar</button>
                </div>
            </div>
        </div>
    </div>
</body>
<script>
    const questoes = <?php echo json_encode($questoes); ?>
</script>
<script src="./javascripts/processa_simulado.js"></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $funcao = cargo( $sql , $id , $user);
    $nome = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $materias = materias_sede($sql , $id);
    $aluno_id = id_aluno($sql , $user);
    $resultados = results_simulado($sql , $id , $aluno_id);
    $descricao = desc_sede($sql , $id);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/sede.css">
    <title>Erudere</title>
</head>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <h1>Pagina de sede</h1>
        <br><br><div id="desempenho">
            <canvas id="canva"></canvas>
            <div id="relatorio_simulado">
                <div id="relatorio" style = "padding-left: 5px; padding-right:5px;">
                    <br>
                    <?php echo $descricao; ?>
                </div>
                <br><a href="./filtro_simulado.php"><input type="button" class="simulado" value="fazer simulado"></a>
                <br><?php
                    if ($funcao === "Professor"){
                        echo "<a href='./cadas_questao.php'><input type='button' class='simulado' value='inserir nova questão'></a>";
                    }?>
            </div><br>
        </div>
        <br><div id="mais">

        </div>
    </div>
</body>
<script>
    const materias = <?php echo json_encode($materias); ?>;
    const results = <?php echo json_encode($resultados); ?>;
    console.log(results);
    
</script>
<script src="./javascripts/grafico.js"></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $user = $_SESSION["user"];
    if ( isset($_SESSION["id_sede"])){
        $id = $_SESSION["id_sede"];
        $funcao = cargo( $sql , $id , $user);
    }
    $nome = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $senha = senha_usuario($sql , $user);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/consulta.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                <a id="user_log" href="./consulta_perfil.php"><img src='<?php echo $user_foto ; ?>' alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div id="lateral">
            <a href="./sedes.php">Página de sedes</a>
            <?php 
                if ( isset($_SESSION["id_sede"])){
                if($funcao === "Curador"){
                    echo "<a href='./sede.php'>Página da sede</a>";
                    echo "<a href='./filtro_relat.php'>membros da sede</a>";
                    echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
                    echo "<a href='./materias.php'>matérias da sede</a>";
                    echo "<a href='./feed.php'>feed</a>";
                }
            }
            ?>
            <a href="./amigos.php">amigos</a>
            <a href="./login.html">sair</a>
        </div>
        <div id="pagina">
            <h3>PERFIL:</h3>
            <div id="infos">
                <div id="campos"><br><br><br>
                    <div>
                    <label for="nome">nome:</label>
                    <input type="text" id="nome" value ="<?php echo $nome;?>" id="nome">
                    <button><img src="./imagens/alterar.png" id ="nome_button" alt=""></button>
                    </div>
                    <div>
                    <label for="email">email:</label>
                    <input type="email" disabled = "true" value = '<?php echo $user; ?>'>
                    </div>
                    <div>
                    <label for="senha">senha:</label>
                    <input type="password"  name="" value="<?php echo $senha; ?>" id="senha">
                    <button><img src="./imagens/alterar.png" id="senha_button" alt=""></button>
                    </div>
                    <input type="button" onclick = "alter()" value="salvar alterações" id="save">
                    <div id = "resp" ></div>
                </div>
                <div id="imagem"><br><br>
                    <img src="<?php echo "$user_foto";?>" alt="" id="foto"><br>
                    <input type='file' id='perfil' name='perfil'><br>
                    <input type="button" id="alter" onclick="alter_img()" value="alterar">
                    <br><div id="resp_foto"></div>
                </div>
            </div>
        </div>
</body>
<script src="./javascripts/alter_user.js"></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

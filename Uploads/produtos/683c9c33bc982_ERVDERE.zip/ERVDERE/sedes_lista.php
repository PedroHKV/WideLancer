<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    include "./server_scripts/modulos/mod2_inserts.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $usuario = $_SESSION["user"];
    $nome = nome_user($sql , $usuario);
    $user_foto = foto_usuario($sql , $usuario);
    $sedes = sedes_user($sql , $usuario);
    $sedes_totais = todas_sedes($sql);
    $sedes_user = sedes_user($sql , $usuario);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $data = json_decode(file_get_contents("php://input"), true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid JSON']);
            exit;
        }

        if (isset($data['action']) && $data['action'] === 'add_inscricao') {
            $cargo = $data['cargo'];
            $usuario = $data['usuario'];
            $data_inscricao = $data['data'];
            $sede_id = $data['sede_id'];

            error_log("Dados recebidos: " . print_r($data, true));

            if ($cargo && $usuario && $data_inscricao && $sede_id) {
                try {
                    add_inscricao($sql, $cargo, $usuario, $data_inscricao, $sede_id);
                    echo json_encode(['status' => 'success']);
                } catch (Exception $e) {
                    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
                }
            } else {
                echo json_encode([
                    'status' => 'error', 
                    'message' => 'Missing parameters',
                    'received' => [
                        'cargo' => $cargo,
                        'usuario' => $usuario,
                        'data' => $data_inscricao,
                        'sede_id' => $sede_id
                    ]
                ]);
            }
            exit;
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERVDERE/sedes</title>
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/sedes_lista.css">
    <script>
        let sedesTotais = <?php echo json_encode($sedes_totais); ?>;
        let sedesUser = <?php echo json_encode($sedes_user); ?>;
        let usuario = <?php echo json_encode($usuario); ?>;
        let sedes_user = sedesUser.map(sede => sede[1]);
        let user_php = <?php echo json_encode($usuario); ?>;
        </script>
    <script src="./javascripts/sedes_lista.js"></script>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" id="pesquisa-input" placeholder="Pesquisar uma sede para enviar solicitação" onkeyup="pesquisarSedes()">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src="<?php echo $user_foto; ?>" alt="."></a>
                    <span><?php echo $nome ; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php"> Página de Sedes</a>
        <a href="./sedes_lista.php">Ver todas as sedes</a>
        <a href="./form_sedes.php">Criar sede</a>
        <a href="./amigos.php">Amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <br><h1>SEUS CURSOS</h1>
        <div id="fundo">
             <div id="lista">
                <?php
                    foreach ($sedes_totais as $sede) {
                        echo "<br><div class='accordion' style='width: 100%; display: flex; flex-direction: column; align-items: center; cursor: pointer; height: max-content;'>
                                <div class='sede'>
                                    <p style='font-weight: bold; font-size: 1.2em;'>".htmlspecialchars($sede['nome'])."</p>
                                </div>
                                <div class='panel sede' style='display: none; padding: 10px; align-items: center; justify-content: space-between; height: 120px;'>
                                    <img 
                                    style='width: 80px; height: 80px; object-fit: cover; border-radius: 10px; margin-right: 10px;'
                                    src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2KcsMXuRvJolFQmNR9_dwEGgXwJ6FVU1vaA&s' alt='Imagem da sede' />
                                    <div style='flex-grow: 1;'>
                                        <p style='font-size: 0.9em; color: #fff;'>
                                          ".$sede["descricao"]."
                                        </p>
                                    </div>
                                    <div style='display: flex; align-items: center; gap: 10px;'>
                                      <button onclick='ingressarComCargo(\"".$sede['id']."\")' style='background-color: #007BFF; color: white; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer; transition: background-color 0.3s;'>
                                          Ingressar
                                      </button>
                                      <select class='styled-select' id='cargo-select-".$sede['id']."'>                                        
                                          <option value='aluno'>Aluno</option>
                                          <option value='curador'>Curador</option>
                                          <option value='professor'>Professor</option>
                                      </select>
                                    </div>
                                </div>
                              </div>";
                    }
                ?>
            </div>
        </div>
    </div>
</body>
<script src="./javascripts/acessibilidade.js"></script>
</html>

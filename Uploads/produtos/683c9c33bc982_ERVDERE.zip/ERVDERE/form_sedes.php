<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    include "./server_scripts/modulos/mod2_inserts.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $usuario = $_SESSION["user"];
    $nome_user = nome_user($sql , $usuario);
    $user_foto = foto_usuario($sql , $usuario);
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERVDERE/sedes</title>
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/sedes_form.css">
    <script>
        let sedesTotais = <?php echo json_encode($sedes_totais); ?>;
        let sedesUser = <?php echo json_encode($sedes_user); ?>;
        let usuario = <?php echo json_encode($usuario); ?>;
        let sedes_user = sedesUser.map(sede => sede[1]);
        let user_php = <?php echo json_encode($usuario); ?>;
        </script>
    <script src="./javascripts/sedes_lista.js"></script>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" id="pesquisa-input" placeholder="Pesquisar uma sede para enviar solicitação" onkeyup="pesquisarSedes()">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src="<?php  echo $user_foto ; ?>" alt="."></a>
                    <span><?php echo $nome_user;?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php"> Página de Sedes</a>
        <a href="./sedes_lista.php">Ver todas as sedes</a>
        <a href="./form_sedes.php">Criar sede</a>
        <a href="./amigos.php">Amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="infosedet">
            <h2>NOVA SEDE:</h2>
        </div>
        <main id="cadasede"></main>
            <form method="POST" action="http://localhost/ERVDERE/server_scripts/cadas_sedes.php" id="infosede">
                <div id="nomesede">
                    <h3>Nome da sede:</h3>
                    <input id="nomeseden" name="nome" type="text" placeholder="Nome...">
                </div>
                <div id="endereço">                   
                    <h3>Escreva o endereço da sede:</h3>                   
                    <input id="endereçon" name="endereco" type="text" placeholder="Rua...">
                </div>
                <div id="cidade">                
                    <h3>em qual cidade fica a sede?</h3>                          
                    <input id="cidaden" name="cidade" type="text" placeholder="Cidade...">
                </div>
                <div id="aditivos">
                    <div id="objetivosede">
                        <h3 id="objetivoseden">Qual o objetivo da sede:</h3>
                        <textarea name="obj" rows="4" cols="50"></textarea>
                    </div>
                </div><br>
                <div id="butonenviar">
                    <button type="submit" id="enviar" onclick="cadas_sede()">Cadastrar</button>
                </div>
            </form>
        </div>
    </main>
    </div>    
</body>
<script src="./javascripts/cadas_sedes.js"></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

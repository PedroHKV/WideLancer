<?php
 include "./server_scripts/modulos/chat.php";
 include "./server_scripts/modulos/mod1_consultas.php";
session_start();
$usuario_email = $_SESSION["user"] ;
$sql = new mysqli("localhost", "root", "", "erudere");

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    switch ($action) {
        case 'carregar_mensagens':
            $amigo_email = isset($_GET['amigo_email']) ? $_GET['amigo_email'] : '';
            carregarMensagens($sql, $usuario_email, $amigo_email);
            break;
        case 'remover_amigo':
            removerAmigo($sql, $usuario_email);
            break;
        case 'aceitar_solicitacao':
            aceitarSolicitacao($sql, $usuario_email);
            break;
        case 'recusar_solicitacao':
            recusarSolicitacao($sql, $usuario_email);
            break;
        default:
            echo "Ação não reconhecida.";
            exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['mensagem'])) {
        enviarMensagem($sql, $usuario_email);
    } elseif (isset($_POST['destinatario'])) {
        enviarSolicitacao($sql, $usuario_email);
    }
}

$usuario_id = id_user($sql, $usuario_email);
$solicitacoes_pendentes = pendentes( $sql , $usuario_id);
$amigos =amigos($sql , $usuario_id);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/amigos.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
                <div id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png">
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src="./imagens/amigo.png" alt="Foto do usuário"></a>
                    <span>Usuário</span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de Sedes</a>
        <a href="./amigos.php">Amigos</a>
        <a href="./login.html">Sair</a>
    </div>
    <div id="pagina" style="display: flex; flex-direction: column; margin-top: 20px; gap: 20px;">
        <div style="display: flex; justify-content: space-between; width: 100%; max-width: 1200px; margin-top: 150px; gap: 20px; align-items: center;">
            <div class="solicitacoes" style="min-width: 48%; height: 120px; background-color: #f9f9f9; padding: 20px; border-radius: 8px;">
                <h2 style="margin-bottom: 10px;">Solicitações de Amizade</h2>
                <?php
                if ($solicitacoes_pendentes->num_rows > 0) {
                    while ($solicitacao = $solicitacoes_pendentes->fetch_assoc()) {
                        echo "<p style='margin-bottom: 10px;'>" . htmlspecialchars($solicitacao['remetente_email']) . "</p>";
                        echo "<button class='aceitar-solicitacao' style='background-color: green; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 5px;' data-remetente-email='" . htmlspecialchars($solicitacao['remetente_email']) . "'>Aceitar</button>";
                        echo "<button class='recusar-solicitacao' style='background-color: red; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 5px; margin-left: 5px;' data-remetente-email='" . htmlspecialchars($solicitacao['remetente_email']) . "'>Recusar</button>";
                    }
                } else {
                    echo "<p>Nenhuma solicitação de amizade pendente.</p>";
                }
                ?>
            </div>
            <div class="adicionar-amigo" style="width: 48%; max-width: 400px;">
                <form id="adicionar-amigo-form" method="POST" style="display: flex; flex-direction: row; align-items: center; gap: 10px;">
                    <input type="text" name="destinatario" placeholder="Digite o email do amigo" required style="padding: 10px; border: 1px solid #ccc; border-radius: 5px; width: 100%;">
                    <button type="submit" style="background-color: green; color: white; border: none; padding: 10px 15px; cursor: pointer; border-radius: 5px; width: max-content; min-width: 150px;">Adicionar Amigo</button>
                </form>
            </div>
        </div>

        <div class="amigos" style="flex: 1; background-color: #f9f9f9; padding: 20px; border-radius: 8px; display: flex; flex-direction: column;">
            <h2>Amigos</h2>
            <?php
            if ($amigos->num_rows > 0) {
                while ($amigo = $amigos->fetch_assoc()) {
                    if (isset($amigo['email'])) {
                        echo "<div class='amigo' style='margin-bottom: 100px;'>".
                                 "<img class='amico' src='".foto_usuario($sql , $amigo['email'])."' alt='Foto do " . htmlspecialchars($amigo['nome']) . "'>".
                                  "<p style='color: white;'>" . htmlspecialchars($amigo['nome']) . " (" . htmlspecialchars($amigo['email']) . ")</p>".
                                "<div class='botoes' style='display: flex; justify-content: space-between; gap: 10px;'><br><br><br>".
                                    "<button class='remover-amigo' style='background-color: #ccc; color: black; border: none; padding: 5px 10px; cursor: pointer; border-radius: 10px;' data-amigo-email='" . htmlspecialchars($amigo['email']) . "'>Remover</button>".
                                    "<button class='enviar-mensagem' style='background-color: #4C127F; color: white; border: none; padding: 5px 5px; cursor: pointer; border-radius: 10px; width: max-content; margin-top: 10px;' data-amigo-email='" . htmlspecialchars($amigo['email']) . "'>Mensagem</button>".
                                "</div>".
                            "</div>";
                    }
                }
            } else {
                echo "<p>Você ainda não tem amigos adicionados.</p>";
            }
            ?>	
        </div>

        </div>
    </div>

    <div id="chat-container" style="display: none;">
        <h2>Chat</h2>
        <div id="mensagens">
        </div>
        <form id="form-mensagem">
            <input type="hidden" id="destinatario_email" name="destinatario_email">
            <input type="text" id="mensagem" name="mensagem" placeholder="Digite sua mensagem" required>
            <button type="submit">Enviar</button>
        </form>
    </div>
    <script src="./javascripts/chat.js" ></script>
</body>
</html>

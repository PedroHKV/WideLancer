<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $funcao = cargo( $sql , $id , $user);
    $nome = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $assuntos = sede_assuntos($sql , $id);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/cadas_questao.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="cadas_q">
            <form id="form" action="">
                NOVA QUESTÃO
                <br><br><br><br><div id ="form-spaces">
                    <div id="cabecalho">
                        <div class = "campo">
                            titulo:
                            <input placeholder="titulo" id="titulo" type="text">
                        </div><br>
                        <div>
                            <select name="assunto" id="assunto">
                                <option value="0">assunto</option>
                                <?php
                                    foreach ( $assuntos as $assunto){
                                        echo "<option value='".$assunto[0]."'>".$assunto[1]."</option>";
                                    }
                                ?>
                            </select>
                        </div><br>
                        <div>
                            <input type="file" id="img" name = "img">
                        </div>
                        <div>
                            <textarea placeholder="enunciado da questão" name="enunciado" id="enunciado"></textarea><br>
                        <div id = "resp"></div>
                        </div>
                    </div>
                    <div id="opcoes">
                        Alternativas da questão: <br><br> 
                        <input type="text" id="alt1" placeholder="opção 1" class="opcao"><input id="1" type="radio"name="verdadeira">verdadeira<br><br>
                        <input type="text" id="alt2" placeholder="opção 2" class="opcao"><input id="2" type="radio"name="verdadeira">verdadeira<br><br>
                        <input type="text" id="alt3" placeholder="opção 3" class="opcao"><input id="3" type="radio"name="verdadeira">verdadeira<br><br>
                        <input type="text" id="alt4" placeholder="opção 4" class="opcao"><input id="4" type="radio" name="verdadeira">verdadeira<br><br>
                        <input type="text" id="alt5" placeholder="opção 5" class="opcao"><input id="5" type="radio" name="verdadeira">verdadeira<br><br>
                    </div>
                </div>
                <br><br>
                <input type="button" onclick= "cadastrar_questao()" value="cadastrar" id="cadas">
            </form>
        </div>
    </div>
</body>
<script src="./javascripts/cadas_questao.js" ></script>
<script src="./javascripts/acessibilidade.js"></script>
</html>

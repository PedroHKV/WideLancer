<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $funcao = cargo( $sql , $id , $user);
    $nome = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $assuntos = sede_assuntos($sql , $id);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/filtro_simulado.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="main">
        <form action="./simulado.php" method="POST" id="form-simulado">
    <h3>Como deverá ser o simulado?</h3>
    <br><br>
    <div id="campos">
        <div>
            <p>Número de questões:</p>
            <input id="num" type="number" name="num" required>
        </div>
        <div>
            <p>Assuntos:</p>
            <div class="dropdown" id="assuntos-dropdown">
                <button id="assuntos-btn" type="button">Selecione os assuntos</button>
                <div class="dropdown-content">
                    <div class="checkbox-group">
                        <?php
                        foreach ($assuntos as $assunto) {
                            echo "<label><input type='checkbox' name='assuntos[]' value='".$assunto[0]."'>".$assunto[1]."</label>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div><br><br>
    <div id="botao">
        <div id="resposta"></div>
        <input type="button" id="enviar-simulado" value="Iniciar simulado">
    </div>
</form>
        </div>
    </div>
    <script src="./javascripts/checkbox.js"></script>
    <script src="./javascripts/iniciar_simulado.js"></script>
</body>
<script src="./javascripts/acessibilidade.js"></script>
</html>

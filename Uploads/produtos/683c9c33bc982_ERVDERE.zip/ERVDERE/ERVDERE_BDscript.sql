CREATE DATABASE IF NOT EXISTS erudere;
USE erudere;


CREATE TABLE IF NOT EXISTS usuario (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) NOT NULL UNIQUE,
    senha VARCHAR(100) NOT NULL ,
    nome VARCHAR(100) NOT NULL,
    foto_perfil VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS aluno(
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id)
);

CREATE TABLE IF NOT EXISTS inscricoes(
    id INT PRIMARY KEY AUTO_INCREMENT,
    cargo VARCHAR(10),
    usuario VARCHAR(100),
    data DATE,
    sede_id INT
);

CREATE TABLE IF NOT EXISTS professor(
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id)
);

CREATE TABLE IF NOT EXISTS curador(
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES usuario(id)
);

CREATE TABLE IF NOT EXISTS solicitacao(
    id INT PRIMARY KEY AUTO_INCREMENT,
    status_solic VARCHAR(10),
    data_solic DATE, 
    id_professor INT,
    id_aluno INT,
    id_curador INT,
    FOREIGN KEY (id_aluno) REFERENCES aluno(id),
    FOREIGN KEY (id_professor) REFERENCES professor(id),
    FOREIGN KEY (id_curador) REFERENCES curador(id)
);

CREATE TABLE IF NOT EXISTS chat(
    id INT PRIMARY KEY AUTO_INCREMENT,
    seg_participante VARCHAR(100) NOT NULL,
    usuario_id INT,
    FOREIGN KEY (usuario_id) REFERENCES usuario(id)
);

CREATE TABLE IF NOT EXISTS mensagem (
  id int NOT NULL AUTO_INCREMENT,
  chat_idchat int DEFAULT NULL,
  data_msg datetime DEFAULT NULL,
  remetente_id int NOT NULL,
  destinatario_id int NOT NULL,
  conteudo text NOT NULL,
  PRIMARY KEY (id),
  KEY remetente_id (remetente_id),
  KEY destinatario_id (destinatario_id)
);

CREATE TABLE IF NOT EXISTS sede(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    endereco_cidade VARCHAR(30),
    endereco_rua VARCHAR(100),
    descricao TEXT 
);

CREATE TABLE IF NOT EXISTS sede_professor(
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_sede INT,
    id_professor INT,
    FOREIGN KEY (id_sede) REFERENCES sede(id),
    FOREIGN KEY (id_professor) REFERENCES professor(id)
);

CREATE TABLE IF NOT EXISTS sede_aluno(
    id INT PRIMARY KEY AUTO_INCREMENT,
    sede_idsede INT ,
    id_aluno INT , 
    FOREIGN KEY (sede_idsede) REFERENCES sede(id),
    FOREIGN KEY (id_aluno) REFERENCES aluno(id)
);

CREATE TABLE IF NOT EXISTS sede_curador(
    id INT PRIMARY KEY AUTO_INCREMENT,
    curador_id INT ,
    sede_id INT ,
    FOREIGN KEY (sede_id) REFERENCES sede(id),
    FOREIGN KEY (curador_id) REFERENCES curador(id)
);

CREATE TABLE IF NOT EXISTS simulado(
    id INT PRIMARY KEY AUTO_INCREMENT,
    aluno_id INT,
    FOREIGN KEY (aluno_id) REFERENCES aluno(id)
);

CREATE TABLE IF NOT EXISTS questao(
    id INT PRIMARY KEY AUTO_INCREMENT,
    alternativas TINYTEXT,
    resposta TEXT
);

CREATE TABLE IF NOT EXISTS simulado_questão(
    id INT PRIMARY KEY AUTO_INCREMENT,
    acerto INT,
    id_questão INT,
    id_simulado INT,
    FOREIGN KEY (id_questão) REFERENCES questao(id),
    FOREIGN KEY (id_simulado) REFERENCES simulado(id)
);

CREATE TABLE IF NOT EXISTS materia(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS professor_materia(
    id INT PRIMARY KEY AUTO_INCREMENT,
    professor_id INT,
    materia_id INT,
    FOREIGN KEY (professor_id) REFERENCES professor(id),
    FOREIGN KEY (materia_id) REFERENCES materia(id)
);

CREATE TABLE IF NOT EXISTS sede_materia(
    id INT PRIMARY KEY AUTO_INCREMENT,
    sede_id INT,
    materia_id INT,
    FOREIGN KEY (sede_id) REFERENCES sede(id),
    FOREIGN KEY (materia_id) REFERENCES materia(id)
);

CREATE TABLE IF NOT EXISTS assunto(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(100),
    materia_id INT,
    importancia INT,
    FOREIGN KEY (materia_id) REFERENCES materia(id)
);

CREATE TABLE IF NOT EXISTS post(
    id INT PRIMARY KEY AUTO_INCREMENT,
    curador_id INT,
    professor_id INT,
    data_de_postagem DATETIME,
    assunto_id INT,
    FOREIGN KEY (curador_id) REFERENCES curador(id),
    FOREIGN KEY (assunto_id) REFERENCES assunto(id)
);


CREATE TABLE IF NOT EXISTS assunto_questao(
    id INT PRIMARY KEY AUTO_INCREMENT,
    assunto_id INT,
    questao_id INT,
    FOREIGN KEY (assunto_id) REFERENCES assunto(id),
    FOREIGN KEY (questao_id) REFERENCES questao(id)
);


CREATE TABLE IF NOT EXISTS conteudo(
    id INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(100),
    mensagem_id INT,
    questao_id INT,
    post_id INT,
    FOREIGN KEY (mensagem_id) REFERENCES mensagem(id),
    FOREIGN KEY ( questao_id) REFERENCES questao(id),
    FOREIGN KEY (post_id ) REFERENCES post(id)
);


CREATE TABLE IF NOT EXISTS texto(
    id INT PRIMARY KEY AUTO_INCREMENT,
    conteudo_id INT,
    texto_conteudo TEXT NOT NULL,
    FOREIGN KEY (conteudo_id) REFERENCES conteudo(id)
);

CREATE TABLE IF NOT EXISTS video(
    id INT PRIMARY KEY AUTO_INCREMENT,
    endereco_video VARCHAR(100),
    conteudo_id INT,
    FOREIGN KEY (conteudo_id) REFERENCES conteudo(id)
);

CREATE TABLE IF NOT EXISTS imagem(
    id INT PRIMARY KEY AUTO_INCREMENT,
    endereco_imagem VARCHAR(100),
    conteudo_id INT,
    FOREIGN KEY (conteudo_id) REFERENCES conteudo(id)
);

CREATE TABLE IF NOT EXISTS amigos (
    id INT PRIMARY KEY AUTO_INCREMENT,
    usuario1_id INT,
    usuario2_id INT,
    FOREIGN KEY (usuario1_id) REFERENCES usuario(id),
    FOREIGN KEY (usuario2_id) REFERENCES usuario(id)
);


CREATE TABLE IF NOT EXISTS solicitacoes_amizade (
  id int NOT NULL AUTO_INCREMENT,
  remetente_id int DEFAULT NULL,
  destinatario_id int DEFAULT NULL,
  status varchar(20) DEFAULT NULL,
  data_solicitacao date DEFAULT NULL,
  PRIMARY KEY (id),
  KEY remetente_id (remetente_id),
  KEY destinatario_id (destinatario_id)
);

DELIMITER $$
CREATE PROCEDURE criar_sede 
    (IN curador INT, 
     IN snome VARCHAR(100), 
     IN cidade VARCHAR(30), 
     IN rua VARCHAR(100), 
     IN obj TEXT)
BEGIN
    DECLARE id_sede_ INT; DECLARE id_curador INT;
    INSERT INTO sede(nome, endereco_cidade, endereco_rua, descricao) VALUES (snome, cidade, rua, obj);
    SET id_sede_ := LAST_INSERT_ID();
    INSERT INTO curador(id_usuario) VALUES (curador);
    SET id_curador := LAST_INSERT_ID();
    INSERT INTO sede_curador(curador_id, sede_id) VALUES (curador, id_sede_);
END $$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE cadastrar_materia
    ( IN sede INT,
      IN materia_nome VARCHAR(100),
      IN professor_id_param INT )
BEGIN
    DECLARE id_materia INT;
    INSERT INTO materia(nome) VALUES (materia_nome);
    SET id_materia := LAST_INSERT_ID();
    INSERT INTO professor_materia(professor_id , materia_id) VALUES (professor_id_param , id_materia);
    INSERT INTO sede_materia(sede_id , materia_id) VALUES (sede , id_materia);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE post_conteudo 
    ( IN professor INT ,
      IN assunto INT ,  
      IN titulo_input VARCHAR(100) ,
      IN descricao TEXT ,
      IN caminho VARCHAR(100))
BEGIN
    DECLARE id_post INT; DECLARE id_content INT ;
    INSERT INTO post(data_de_postagem,curador_id,assunto_id,professor_id) VALUES ( NOW() , NULL , assunto , professor);
    SET id_post := (SELECT LAST_INSERT_ID());
    INSERT INTO conteudo(titulo , mensagem_id ,questao_id,post_id) VALUES( titulo_input ,NULL , NULL , id_post);
    SET id_content := (SELECT LAST_INSERT_ID());
    INSERT INTO texto(conteudo_id , texto_conteudo) VALUES (id_content , descricao);
    INSERT INTO video(conteudo_id , endereco_video) VALUES (id_content , caminho);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE cadas_user
	(IN nome VARCHAR(100),
     IN email VARCHAR(100),
     IN senha VARCHAR(100))
BEGIN
DECLARE id_user INT ; 
INSERT INTO usuario(nome , email , senha) VALUES (nome , email , senha);
SET id_user = LAST_INSERT_ID();
INSERT INTO professor(id_usuario) VALUES (id_user);
INSERT INTO curador(id_usuario) VALUES (id_user);
INSERT INTO aluno(id_usuario) VALUES (id_user);
END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE cadas_questao 
	(IN assunto INT , 
	 IN titulo VARCHAR(100),
     IN caminho VARCHAR(100),
     IN enunciado TEXT,
     IN alternativas_i TINYTEXT,
     IN verdad TINYTEXT)
BEGIN
	DECLARE id_questao INT ; DECLARE id_conteudo INT;
    INSERT INTO questao(alternativas,resposta) VALUES (alternativas_i,verdad);
    SET id_questao := LAST_INSERT_ID();
    INSERT INTO assunto_questao(assunto_id , questao_id) VALUES (assunto , id_questao);
    INSERT INTO conteudo(titulo, mensagem_id, questao_id, post_id) VALUES (titulo, NULL, id_questao, NULL);
    SET id_conteudo := LAST_INSERT_ID();
    INSERT INTO imagem(endereco_imagem, conteudo_id) VALUES (caminho , id_conteudo);
    INSERT INTO texto(conteudo_id, texto_conteudo) VALUES (id_conteudo, enunciado);
END $$
DELIMITER ;

    
CREATE VIEW id_prof AS 
SELECT p.id AS id_prof , u.email  , u.id AS id_user FROM
professor AS p 
JOIN usuario AS u ON p.id_usuario = u.id;  

CREATE VIEW id_aluno AS
SELECT a.id AS id_aluno , u.email , u.id AS id_user FROM
aluno AS a
JOIN usuario AS u ON a.id_usuario = u.id;


CREATE VIEW usuario_sedes AS
SELECT 
    u.email AS usuario_email, 
    s.nome AS sede_nome,
    s.id AS sede_id
FROM sede s
LEFT JOIN sede_professor sp ON s.id = sp.id_sede
LEFT JOIN sede_aluno sa ON s.id = sa.sede_idsede
LEFT JOIN sede_curador sc ON s.id = sc.sede_id
LEFT JOIN professor p ON sp.id_professor = p.id
LEFT JOIN aluno a ON sa.id_aluno = a.id
LEFT JOIN curador c ON sc.curador_id = c.id
LEFT JOIN usuario u ON u.id = p.id_usuario OR u.id = a.id_usuario OR u.id = c.id_usuario
WHERE p.id_usuario IS NOT NULL OR a.id_usuario IS NOT NULL OR c.id_usuario IS NOT NULL;

CREATE VIEW sede_professores AS 
SELECT 
    sp.id AS sede_id,
    p.id AS professor_id,
    u.nome AS professor_nome
FROM sede_professor AS sp 
JOIN professor AS p ON p.id = sp.id_professor
JOIN usuario AS u ON u.id = p.id_usuario;

CREATE VIEW sede_curadores AS
SELECT 
    sc.id AS sede_id,
    c.id AS curador_id,
    u.nome AS curador_nome
FROM sede_curador AS sc 
JOIN curador AS c ON c.id = sc.curador_id
JOIN usuario AS u ON u.id = c.id_usuario;

CREATE VIEW sede_alunos AS
SELECT 
    sa.id AS sede_id,
    a.id AS aluno_id,
    u.nome AS aluno_nome
FROM sede_aluno AS sa 
JOIN aluno AS a ON a.id = sa.id_aluno
JOIN usuario AS u ON u.id = a.id_usuario;


CREATE VIEW conteudo_assunto AS
SELECT 
    a.id AS assunto_id,
    p.data_de_postagem,
    p.professor_id,
    c.titulo AS conteudo_titulo,
    t.texto_conteudo,       
    v.endereco_video,      
    i.endereco_imagem        
FROM 
    assunto AS a
LEFT JOIN  post AS p ON p.assunto_id = a.id
LEFT JOIN  conteudo AS c ON c.post_id = p.id
LEFT JOIN  texto AS t ON t.conteudo_id = c.id
LEFT JOIN  video AS v ON v.conteudo_id = c.id
LEFT JOIN  imagem AS i ON i.conteudo_id = c.id;

DELIMITER $$
CREATE PROCEDURE post_feed 
    (  IN curadorid INT,
       IN titulo VARCHAR(100),
       IN texto TEXT,
       IN caminho VARCHAR(100)
    )
BEGIN
    DECLARE id_post INT; DECLARE id_content INT ;
    INSERT INTO post(data_de_postagem,curador_id,assunto_id,professor_id) VALUES ( NOW() , curadorid , NULL , NULL);
    SET id_post := (SELECT LAST_INSERT_ID());
    INSERT INTO conteudo(titulo , mensagem_id ,questao_id,post_id) VALUES (titulo , NULL , NULL , id_post);
    SET id_content := (SELECT LAST_INSERT_ID());
    INSERT INTO texto(conteudo_id , texto_conteudo) VALUES (id_content , texto);
    INSERT INTO imagem( endereco_imagem , conteudo_id) VALUES( caminho , id_content);
END $$
DELIMITER ;



CREATE VIEW nome_professor AS
SELECT 
    pr.id AS professor_id, 
    u.nome AS professor_nome
FROM professor AS pr
JOIN usuario AS u ON u.id = pr.id_usuario;

CREATE VIEW sede_materias AS
SELECT sm.sede_id AS sede_id, m.id AS id_materia, m.nome AS nome_materia
FROM sede_materia AS sm
JOIN materia AS m ON sm.materia_id = m.id;

CREATE VIEW user_funcoes AS
SELECT 
    u.email AS usuario_email,
    s.id AS sede_id,
    CASE 
        WHEN sa.id IS NOT NULL THEN 'Aluno' 
        WHEN sp.id IS NOT NULL THEN 'Professor'
        WHEN sc.id IS NOT NULL THEN 'Curador'
        ELSE 'Nenhum Cargo'
    END AS cargo
FROM usuario u
LEFT JOIN sede_aluno sa ON u.id = sa.id_aluno
LEFT JOIN sede_professor sp ON u.id = sp.id_professor
LEFT JOIN sede_curador sc ON u.id = sc.curador_id
LEFT JOIN sede s ON s.id IN (sa.sede_idsede, sp.id_sede, sc.sede_id)
ORDER BY u.nome, s.nome;

CREATE VIEW nome_curador AS
SELECT 
    c.id AS curador_id,
    u.nome AS usuario_nome
FROM curador AS c
JOIN usuario AS u ON u.id = c.id_usuario;

CREATE VIEW foto_professor AS
SELECT 
    pr.id AS professor_id, 
    u.foto_perfil AS foto_perfil
FROM professor AS pr
JOIN usuario AS u ON u.id = pr.id_usuario;

CREATE VIEW foto_usuario AS
SELECT 
    u.email AS usuario_email, 
    u.foto_perfil AS foto_perfil
FROM usuario AS u;


CREATE VIEW id_curad AS
SELECT c.id AS id_curad, u.email
FROM curador AS c
JOIN usuario AS u ON u.id = c.id_usuario;

CREATE VIEW sede_assuntos AS
SELECT 
    s.id AS sede_id, 
    a.id AS assunto_id,
    a.nome AS assunto_nome
FROM sede AS s
JOIN sede_materia AS sm ON sm.sede_id = s.id
JOIN materia AS m ON sm.materia_id = m.id
JOIN assunto AS a ON a.materia_id = m.id;

CREATE VIEW sede_posts AS
SELECT 
    s.id AS sede_id,
    sc.curador_id,
    c.titulo AS titulo,
    t.texto_conteudo AS texto,
    i.endereco_imagem AS imagem,
    p.data_de_postagem AS data_postagem
FROM sede AS s
JOIN sede_curador AS sc ON sc.sede_id = s.id
JOIN post AS p ON p.curador_id = sc.curador_id
LEFT JOIN conteudo AS c ON c.post_id = p.id
LEFT JOIN texto AS t ON t.conteudo_id = c.id
LEFT JOIN imagem AS i ON i.conteudo_id = c.id;

CREATE VIEW conteudo_questoes AS
SELECT 
    a.id AS assunto_id,
    a.nome AS assunto_nome,
    q.id AS questao_id,
    c.titulo AS titulo,
    q.resposta AS resposta,
    t.texto_conteudo AS enunciado,
    q.alternativas AS alternativas,
    i.endereco_imagem AS imagem
FROM 
    assunto AS a
JOIN assunto_questao AS aq ON aq.assunto_id = a.id
JOIN questao AS q ON q.id = aq.questao_id
LEFT JOIN conteudo AS c ON c.questao_id = q.id
LEFT JOIN texto AS t ON t.conteudo_id = c.id
LEFT JOIN imagem AS i ON i.conteudo_id = c.id;

CREATE VIEW questao_materia AS
SELECT 
    q.id AS questao_id,
    m.id AS materia_id,
    m.nome AS materia_nome
FROM questao AS q
JOIN assunto_questao AS aq ON q.id = aq.questao_id
JOIN assunto AS a ON a.id = aq.assunto_id
JOIN materia AS m ON m.id = a.materia_id;


DELIMITER $$

CREATE VIEW simuls_user AS
SELECT 
    sm.sede_id,
    m.nome AS materia_nome,
    COUNT(sq.acerto) AS total_acertos
FROM sede_materia sm
JOIN materia m ON sm.materia_id = m.id
JOIN questao_materia qm ON qm.materia_id = m.id
JOIN simulado_questão sq ON sq.id_questão = qm.questao_id
JOIN simulado s ON s.id = sq.id_simulado
JOIN sede_aluno sa ON sa.id_aluno = s.aluno_id
WHERE sa.sede_idsede = sm.sede_id
GROUP BY sm.sede_id, m.id;


CREATE VIEW results_simulado AS
SELECT 
    a.id AS aluno_id,
    sm.sede_id AS id_sede, 
    m.id AS materia_id,
    m.nome AS materia_nome,  
    COALESCE(SUM(CASE WHEN sq.acerto = 1 THEN 1 ELSE 0 END), 0) AS acertos,
    COALESCE(SUM(CASE WHEN sq.acerto = 0 THEN 1 ELSE 0 END), 0) AS erros
FROM sede_materia sm
JOIN materia m ON sm.materia_id = m.id
LEFT JOIN assunto ass ON ass.materia_id = m.id
LEFT JOIN assunto_questao aq ON aq.assunto_id = ass.id
LEFT JOIN questao q ON q.id = aq.questao_id
LEFT JOIN simulado_questão sq ON sq.id_questão = q.id
LEFT JOIN simulado s ON s.id = sq.id_simulado
LEFT JOIN aluno a ON a.id = s.aluno_id
GROUP BY a.id, m.id
ORDER BY a.id, m.id;

CREATE PROCEDURE save_simul(IN id_aluno INT, IN resultados_json JSON)
BEGIN
    DECLARE i INT DEFAULT 0;
    DECLARE questao_id INT;
    DECLARE acerto INT;
    DECLARE num_elementos INT;
    DECLARE id_simulado INT;

    INSERT INTO simulado(aluno_id) VALUES (id_aluno);
    SET id_simulado = LAST_INSERT_ID();
    
    SET num_elementos = JSON_LENGTH(resultados_json);
    
    WHILE i < num_elementos DO
        SET questao_id = CAST(JSON_UNQUOTE(JSON_EXTRACT(resultados_json, CONCAT('$[', i, '][0]'))) AS UNSIGNED);
        SET acerto = CAST(JSON_UNQUOTE(JSON_EXTRACT(resultados_json, CONCAT('$[', i, '][1]'))) AS UNSIGNED);
        
        INSERT INTO simulado_questão (acerto, id_questão, id_simulado) 
        VALUES (acerto, questao_id, id_simulado);
        
        SET i = i + 1;
    END WHILE;
    
END $$

DELIMITER ;
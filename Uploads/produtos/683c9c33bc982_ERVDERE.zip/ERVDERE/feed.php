<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id_sede = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $funcao = cargo( $sql , $id_sede , $user);
    $nome_user = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $sede_posts = sede_posts($sql , $id_sede);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/feed.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <main>
            <div id="logo">
                <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
            </div>
            <div id="resto">
                <div id="pesquisa">
                    <input type="text" placeholder="Pesquisar...">
                </div>
                <div id="user">
                <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                    </div>
                    <div id="usuario">
                    <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                        <span><?php echo $nome_user; ?></span>
                    </div>
                </div>
            </div>
        </main>
    </header>
    <div id="lateral">
        <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <div id="feedt">
            <h2>Noticias da sede</h2>
            <?php
                if ($funcao === "Curador"){
                    echo "<button id='post_feed'><a href='./form_feed.php'>novo post</a></button>";
                }            
            ?>
        </div>

        <?php
            foreach ($sede_posts as $post) {
                $curador_id = $post[1];
                $curador_nome = nome_curador($sql , $curador_id);
                echo  "<div class='postagem'>".
                        "<div class='titulon'>".
                            "<h1>".$post[2]."</h1>".
                    " </div>".
                        "<div class='imagem'>".
                            "<img src=".$post[4]." alt='imagem_noticia'>".
                    " </div><br><br>".
                        "<div class='texto'>".
                            "<h3>".
                                    $post[3].
                            "</h3>".
                        "</div><br><br><br>".
                        "<div class='autor'>".
                            "<h4>Feito por ".$curador_nome." em ".$post[5]."</h4>".
                    " </div>".
                    "</div><br><br><br>";
            }    
        ?>
    </div>
</body>
<script src="./javascripts/acessibilidade.js"></script>
</html>

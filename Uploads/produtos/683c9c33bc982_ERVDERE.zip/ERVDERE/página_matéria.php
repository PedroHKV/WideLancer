<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $usuario = $_SESSION["user"];
    $materia = $_SESSION["id_mat"];
    $id_sede = $_SESSION["id_sede"];
    $funcao = cargo( $sql , $id_sede , $usuario);
    $nome_mat = nome_materia($sql , $materia);
    $nome = nome_user($sql , $usuario);
    $user_foto = foto_usuario($sql , $usuario);
    $assuntos = assuntos_materia($sql , $materia);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/página_matéria.css">
    <title>Erudere</title>
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
    <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <br><div id="adicionar" style = "flex-direction:column; margin-left:85%;">
            <?php
                if ( $funcao !== "Aluno"){
                    echo "<a href='./novo_assunto.php'>+</a>".
                         "<h3>Adicionar assunto</h3>";
                }
            ?>
        </div>
        <h2><?php echo $nome_mat ; ?></h2><br><br>  
            <?php
                foreach ($assuntos as $assunto) {
                    echo "<div class='assunto'> <a style='height:32px; display:flex; align-items:center;' href='http://localhost/ERVDERE/server_scripts/processa_assunto.php?id_assunt=".$assunto[0]."'>".$assunto[1]."</a> </div><br>";
                }
                
            ?>
    </div>
</body>
<script src="./javascripts/acessibilidade.js"></script>
</html>

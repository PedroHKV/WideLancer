<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    include "./server_scripts/modulos/mod2_inserts.php";
    include "./server_scripts/modulos/mod3_deletes.php";
    include "./server_scripts/modulos/mod4_updates.php"; 
    $sql = new mysqli("localhost", "root", "", "erudere");
    session_start();
    $user = $_SESSION["user"];
    if (isset($_SESSION["id_sede"])){
        $id = $_SESSION["id_sede"];
        $funcao = cargo( $sql , $id , $user);
    }
    $nome = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $action = $_POST['action'];
        $inscricao_id = $_POST['inscricao_id'];
        $cargo = isset($_POST['cargo']) ? $_POST['cargo'] : null;

        if ($action === 'aceitar') {
            echo "Aceitar a inscrição";
            echo "Aceitando inscrição: ID - $inscricao_id, Cargo - $cargo, Sede ID - $id";
            aceitar_inscricao($sql, $inscricao_id, $cargo, $id);
        } elseif ($action === 'recusar') {
            echo "Recusar a inscrição";
            recusar_inscricao($sql, $inscricao_id);
        } else {
            echo "Ação inválida";
        }
    } else {
        echo "Método de requisição inválido";
    }

    $inscricoes = obter_inscricoes($sql, $id);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Inscrições</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/sede.css">
    <link rel="stylesheet" href="lista_inscricoes.css">
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
            <div class="dd" id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png" alt="Acessibilidade" id="acessibilidadeBtn">
                    <div class="dd-content" id="ddMenu">
                        <button id="aumentarFonte"> (+)</button>
                        <button id="diminuirFonte"> (-)</button>
                    </div>
                </div>
                </div>
                </div>
                <div id="usuario">
                <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome; ?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
    <a href="./sedes.php">Página de sedes</a>
        <a href="./sede.php">Página da sede</a>
        <a href="./filtro_relat.php">membros da sede</a>
        <?php 
            if($funcao === "Curador"){
                echo "<a href='./lista_inscricoes.php'>Lista de Inscrições</a>" ;
            }
        ?>
        <a href="./materias.php">matérias da sede</a>
        <a href="./feed.php">feed</a>
        <a href="./amigos.php">amigos</a>
        <a href="./login.html">sair</a>
    </div>
    
    <div id="pagina">
    <h1 style="padding: 20px;">Inscrições da Sede</h1>
    <div id="lista-inscricoes">
        <?php foreach ($inscricoes as $inscricao): ?>
            <div class="inscricao-item">
                <p>Usuário: <?php echo htmlspecialchars($inscricao['usuario'] ?? 'N/A'); ?></p>
                <p>Cargo: <?php echo htmlspecialchars($inscricao['cargo'] ?? 'N/A'); ?></p>
                <p>Data de inscrição: <?php echo htmlspecialchars($inscricao['data'] ?? 'N/A'); ?></p>
                <form method="POST" class="inscricao-form">
                    <input type="hidden" name="inscricao_id" value="<?php echo $inscricao['usuario']; ?>">
                    <input type="hidden" name="cargo" value="<?php echo htmlspecialchars($inscricao['cargo'] ?? 'N/A'); ?>">
                    <button type="submit" name="action" value="aceitar" class="btn-aceitar">Aceitar</button>
                    <button type="submit" name="action" value="recusar" class="btn-recusar">Recusar</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</body>
<script src="./javascripts/acessibilidade.js"></script>
</html> 

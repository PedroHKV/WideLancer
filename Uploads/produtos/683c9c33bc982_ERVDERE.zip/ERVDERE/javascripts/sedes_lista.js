console.log(sedesTotais);

function pesquisarSedes() {
    console.log("Pesquisando sedes...");
    const query = document.getElementById('pesquisa-input').value;
    console.log(`Query: ${query}`);
    
    const lista = document.getElementById('lista');
    lista.innerHTML = '';

    if (query === '') {
        sedesTotais.forEach(sede => {
            const usuarioParticipa = verificarParticipacao(usuario, sede.id);
            console.log(`Adding sede: ${sede.nome}`);
            lista.innerHTML += `<br><div class='sede-container'>
                <a href='http://localhost/ERVDERE/server_scripts/processa_id.php?id=${sede.id}' class='sede'><p>${sede.nome}</p></a>
                ${!usuarioParticipa ? `<button class='entrar-sede' onclick="entrarNaSede(${sede.id})">Entrar nesta sede</button>` : ''}
            </div>`; 
        });
    } else {
        const resultados = sedesTotais.filter(sede => sede.nome.includes(query));
        
        resultados.forEach(sede => {
            const usuarioParticipa = verificarParticipacao(usuario, sede.id);
            console.log(`Adding sede: ${sede.nome}`);
            lista.innerHTML += `<br><div class='sede-container' style='display: flex; align-items: center; margin-bottom: 10px; width: 100%; gap: 10px; padding: 10px;'>
                <a href='http://localhost/ERVDERE/server_scripts/processa_id.php?id=${sede.id}' class='sede' style='text-decoration: none; color: white; width: 100%;'><p>${sede.nome}</p></a>
                ${!usuarioParticipa ? `<button class='entrar-sede' onclick="entrarNaSede(${sede.id})">Entrar nesta sede</button>` : ''}
            </div>`;
        });
    }

    if (lista.innerHTML === '') {
        lista.innerHTML = '<p>Nenhuma sede encontrada.</p>';
    }
}

function verificarParticipacao(usuario, sedeId) {
    return sedes_user.includes(sedeId);
}

function entrarNaSede(sedeId) {
    window.location.href = `http://localhost/ERVDERE/server_scripts/enviar_solicitacao.php?selecao=${sedeId}`;
}

function isInscrito(usuario, sedeId) {
    return sedes_user.includes(sedeId);
}

function ingressarComCargo(sedeId) {
    const select = document.getElementById(`cargo-select-${sedeId}`);
    const cargo = select ? select.value : null;
    const usuario = user_php;
    const data = new Date().toISOString().slice(0, 10);
    const sede_id = sedeId;

    console.log(`Cargo desejado: ${cargo}`);
    console.log(`Usuario: ${usuario}`);
    console.log(`Data: ${data}`);
    console.log(`Sede ID: ${sede_id}`);
    
    if (!cargo || !usuario || !data || !sede_id) {
        console.error('Missing parameters for the request');
        return;
    }

    const isInscrito = verificarParticipacao(usuario, sede_id);
    if (isInscrito) {
        const mensagemErro = document.createElement('div');
        mensagemErro.innerText = 'Você já está inscrito nesta fila de inscrição';
        mensagemErro.style.color = 'red';
        mensagemErro.style.fontSize = '1.2em';
        mensagemErro.style.marginTop = '10px';
        document.getElementById('pagina').prepend(mensagemErro);
        return;
    }

    fetch('http://localhost/ERVDERE/sedes_lista.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'add_inscricao', cargo, usuario, data, sede_id })
    })
    .then(response => response.text())
    .then(text => {
        console.log('Resposta bruta do servidor:', text);
        try {
            return JSON.parse(text);
        } catch (e) {
            console.error('Erro ao fazer parse do JSON:', e);
            throw new Error('Resposta inválida do servidor');
        }
    })
    .then(data => {
        console.log('Resposta processada:', data);
        if (data.status === 'success') {
            const mensagemSucesso = document.createElement('div');
            mensagemSucesso.innerText = 'Sucesso ao ingressar aguarde a aprovação do administrador';
            mensagemSucesso.style.color = 'green';
            mensagemSucesso.style.fontSize = '1.2em';
            mensagemSucesso.style.marginTop = '10px';
            mensagemSucesso.style.width = '100%';
            mensagemSucesso.style.textAlign = 'center';
            mensagemSucesso.style.display = 'flex';
            mensagemSucesso.style.justifyContent = 'center';
            mensagemSucesso.style.alignItems = 'center';
            mensagemSucesso.style.height = '50px';
            document.getElementById('pagina').prepend(mensagemSucesso);
        } else {
            const mensagemErro = document.createElement('div');
            mensagemErro.innerText = 'Erro ao ingressar na sede';
            mensagemErro.style.color = 'red';
            mensagemErro.style.fontSize = '1.2em';
            mensagemErro.style.marginTop = '10px';
            mensagemErro.style.width = '100%';
            mensagemErro.style.textAlign = 'center';
            mensagemErro.style.display = 'flex';
            mensagemErro.style.justifyContent = 'center';
            mensagemErro.style.alignItems = 'center';
            mensagemErro.style.height = '50px';
            document.getElementById('pagina').prepend(mensagemErro);
        }
    })
    .catch((error) => {
        console.error('Erro:', error);
        alert('Erro ao processar a requisição');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.accordion div').forEach(item => {
        item.addEventListener('click', event => {
            const panel = item.nextElementSibling;
            if (panel) {
                const isOpen = panel.style.display === 'flex';
                panel.style.display = isOpen ? 'none' : 'flex';
                panel.style.height = isOpen ? '0' : `${panel.scrollHeight}px`;
                panel.style.minHeight = 'max-content';
                panel.style.transition = 'height 0.3s ease';
            }
        });
    });
});
const alts_simul = document.querySelectorAll(".opcao1");

let ids_questoes = [];
questoes.forEach(questao => {
    ids_questoes.push(questao[5]);
});

let resps_corretas = [];
questoes.forEach(questao => {
    resps_corretas.push(questao[4]);
});

let alternativas = [];
questoes.forEach(questao => {
    alternativas.push(questao[3]);
});

function enviar() {
    let result_simul = [];
    let resps_simul = [];

    alts_simul.forEach(alternativa => {
        if (alternativa.checked) {
            resps_simul.push(alternativa.value);
        }
    });

    for (let i = 0; i < ids_questoes.length; i++) {
        if (resps_simul[i] === resps_corretas[i]) {
            result_simul.push([ids_questoes[i], 1]);
        } else {
            result_simul.push([ids_questoes[i], 0]);
        }
    }
    let result_def = result_simul.map(item => [parseInt(item[0]), item[1]]);
    console.log(JSON.stringify(result_def));
    

    fetch("http://localhost/ERVDERE/server_scripts/result_simulado.php", {
        method: "POST", 
        headers: {
            "Content-Type": "application/json", 
        },
        body: JSON.stringify({ result: result_def }) 
    })
    .then(response => response.text())  .then(data => {
        if (data === "dados_recebidos"){
            window.location.href = "http://localhost/ERVDERE/sede.php";
        } else {
            console.log(data);
        }
    }).catch(error => {
        console.error("Erro ao enviar o resultado:", error);
    });
}

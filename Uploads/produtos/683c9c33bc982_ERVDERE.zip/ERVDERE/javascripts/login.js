function logar(){
    let form = document.getElementById("regist");
    let email = document.getElementById("email");
    let senha = document.getElementById("entrar");
    if ( senha !== "" && email !== ""){
        form.submit();
    } else {
        alert("todos os campos devem estar preenchidos");
    }
}
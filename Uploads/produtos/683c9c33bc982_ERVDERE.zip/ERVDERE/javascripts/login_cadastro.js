function login(){
    const email = document.getElementById("email").value;
    const senha = document.getElementById("entrar").value;

}

function cadastrar() {
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
    const senha = document.getElementById("password").value;
    fetch( "http://localhost/ERVDERE/server_scripts/login_cadastro.php" , {
        method : "POST",
        headers : { "Content-Type" : "application/x-www-form-urlencoded" },
        body : new URLSearchParams( { nome : nome , email : email , senha : senha , func : "cadas" } )
    } ).then( resp => {
        if (!resp.ok) {
            throw new error( "Erro: ${resp.status} ${resp.statusText}"); 
        }
        return resp.text();
    }).then ( dados_resp => {
        alert(dados_resp);
    })
}
const senha = document.getElementById("senha");
const nome = document.getElementById("nome");
const senha_button = document.getElementById("senha_button");
const nome_button = document.getElementById("nome_button");
const resposta = document.getElementById("resp");
const div_img = document.getElementById("imagem");
const foto = document.getElementById("perfil");
const resp_foto = document.getElementById("resp_foto");
senha.disabled = true;
nome.disabled = true;
nome_button.disabled = true;


senha_button.onclick = () => {
    senha.disabled = senha.disabled ? false : true;
}

nome_button.onclick = () => {
    nome.disabled = nome.disabled ? false : true;
}


function alter(){
    let nome_v = nome.value;
    let senha_v = senha.value;
    fetch("http://localhost/ERVDERE/server_scripts/alteruser.php?nome="+nome_v+"&senha="+senha_v , {
        method : "GET"
    }).then(resp => { return resp.text() }).then((resp => { 
        resposta.innerHTML = resp;
        if ( resp === "dados alterados com sucesso"){
            location.reload();
        }
     }))
}

function alter_img(){
    let img = foto.files[0];
    let dados = new FormData();
    dados.append("perfil" , img);
    fetch("http://localhost/ERVDERE/server_scripts/alteruser.php" , {
        method : "POST",
        body : dados
    }).then(resp => { return resp.text();}).then(resp => {
        resp_foto.innerHTML = resp;
    })
}
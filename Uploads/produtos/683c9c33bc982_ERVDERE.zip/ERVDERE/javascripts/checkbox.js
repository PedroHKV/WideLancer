document.getElementById('assuntos-btn').addEventListener('click', function(event) {
    var dropdown = document.getElementById('assuntos-dropdown');
    dropdown.classList.toggle('open');
    event.stopPropagation(); 
});


document.addEventListener('click', function(event) {
    var dropdown = document.getElementById('assuntos-dropdown');
    if (!dropdown.contains(event.target)) {
        dropdown.classList.remove('open');
    }
});
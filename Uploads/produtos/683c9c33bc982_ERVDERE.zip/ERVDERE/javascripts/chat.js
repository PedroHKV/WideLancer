document.querySelectorAll('.remover-amigo').forEach(button => {
    button.addEventListener('click', function() {
        const amigoEmail = this.dataset.amigoEmail;
        if (confirm("Tem certeza que deseja remover este amigo?")) {
            window.location.href = `amigos.php?action=remover_amigo&amigo_email=${encodeURIComponent(amigoEmail)}`;
        }
    });
});

document.querySelectorAll('.aceitar-solicitacao').forEach(button => {
    button.addEventListener('click', function() {
        const remetenteEmail = this.dataset.remetenteEmail;
        window.location.href = `amigos.php?action=aceitar_solicitacao&remetente_email=${encodeURIComponent(remetenteEmail)}`;
    });
});

document.querySelectorAll('.recusar-solicitacao').forEach(button => {
    button.addEventListener('click', function() {
        const remetenteEmail = this.dataset.remetenteEmail;
        window.location.href = `amigos.php?action=recusar_solicitacao&remetente_email=${encodeURIComponent(remetenteEmail)}`;
    });
});

document.querySelectorAll('.enviar-mensagem').forEach(button => {
    button.addEventListener('click', function() {
        const amigoEmail = this.dataset.amigoEmail;
        document.getElementById('destinatario_email').value = amigoEmail;
        document.getElementById('chat-container').style.display = 'block';
        carregarMensagens(amigoEmail);
    });
});

function carregarMensagens(amigoEmail) {
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (this.readyState === XMLHttpRequest.DONE) {
            if (this.status === 200) {
                document.getElementById('mensagens').innerHTML = this.responseText;
            } else {
                alert("Erro ao carregar mensagens.");
            }
        }
    };
    xhr.open('GET', `amigos.php?action=carregar_mensagens&amigo_email=${encodeURIComponent(amigoEmail)}`, true);
    xhr.send();
}

document.getElementById('form-mensagem').addEventListener('submit', function(event) {
    event.preventDefault();
    const destinatarioEmail = document.getElementById('destinatario_email').value;
    const mensagem = document.getElementById('mensagem').value;
    
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (this.readyState === XMLHttpRequest.DONE) {
            if (this.status === 200) {
                document.getElementById('mensagem').value = '';
                carregarMensagens(destinatarioEmail);
            } else {
                alert("Erro ao enviar a mensagem. Tente novamente.");
            }
        }
    };
    xhr.open('POST', 'amigos.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.send(`mensagem=${encodeURIComponent(mensagem)}&destinatario_email=${encodeURIComponent(destinatarioEmail)}`);
});

document.getElementById('solicitacao-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'enviar_solicitacao.php', true);
    xhr.onreadystatechange = function() {
        if (this.readyState === XMLHttpRequest.DONE) {
            let response;
            try {
                // Remove warnings from response text before parsing
                const jsonStart = this.responseText.lastIndexOf('{');
                const jsonText = this.responseText.substring(jsonStart);
                response = JSON.parse(jsonText);
            } catch (e) {
                console.error("Error parsing response:", e);
                response = {
                    status: "error", 
                    message: "Erro ao processar resposta do servidor"
                };
            }
            const messageDiv = document.getElementById('response-message');
            messageDiv.textContent = response.message;
            messageDiv.style.color = response.status === "success" ? "green" : "red";
        }
    };
    xhr.send(formData);
});
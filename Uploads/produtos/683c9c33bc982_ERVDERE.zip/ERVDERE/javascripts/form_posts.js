function postar_feed(){
    const form = document.getElementById("postagem");
    const titulo = document.getElementById("tituloe").value;
    const texto = document.getElementById("textoe").value;
    let aviso = document.getElementById("res_text");

    if(texto !== "" && titulo !== "" ){
        form.submit();
    } else {
        aviso.innerHTML = ("é necessário preencher todos os campos de texto para fazer um post");
    }
}
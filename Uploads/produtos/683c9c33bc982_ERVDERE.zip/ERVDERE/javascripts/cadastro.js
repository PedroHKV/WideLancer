function enviar(){
    let form = document.getElementById("register");
    let nome = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let senha = document.getElementById("password").value;
    if ( nome !== "" && senha !== "" && email !== ""){
        form.submit();
    } else {
        alert("todos os campos devem estar preenchidos");
    }
}
function cadas_sede() {
    let form = document.getElementById("infosede");
    let nome = document.getElementById("nomeseden").value;
    if ( nome !== ""){
        form.submit();
    } else {
        alert("o campo nome deve ser preenchido");
    }    
}
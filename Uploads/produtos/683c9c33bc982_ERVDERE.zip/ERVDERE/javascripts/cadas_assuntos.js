function novo_assunto(){
    const form = document.getElementById("form");
    const nome = document.getElementById("nome").value;
    const importancia = document.getElementById("importancia").value;
    let nome_r = document.getElementById("resp_nome");
    let impo_r = document.getElementById("resp_impor");
    if (importancia > 0 && importancia <= 100 && nome !== ""){
        form.submit();
    } else if ( !(importancia > 0 && importancia <= 100) ){
        impo_r.innerHTML = ("é necessário preencher o campo importancia com um percentual de 1 a 100");
    } else if (nome === "") {
        nome_r.innerHTML =("o campo nome é obrigatorio");
    }
}
document.getElementById('enviar-simulado').addEventListener('click', function(event) {
    const form = document.getElementById('form-simulado');
    const formData = new FormData(form);
    const checkboxes = document.querySelectorAll('input[type="checkbox"][name="assuntos[]"]');
    const numero = parseInt(document.getElementById("num").value);
    let algumSelecionado = false;
    let resp = document.getElementById("resposta");

    checkboxes.forEach(checkbox => {
        if (checkbox.checked && checkbox.value !== "todos") {
            algumSelecionado = true;
        }
    });

    if (!algumSelecionado) {
        checkboxes.forEach(assunto=>{
            formData.append("assuntos[]",assunto.value);
        })
    }

    if (numero === 0){
        resp.innerHTML = ("informe quantas questões estarão presentes no simulado");
    } else if (!algumSelecionado) {
        resp.innerHTML = ( "você deve selecionar pelo menos um assunto antes de iniciar o simulado" );
    } else if(numero === "" || isNaN(numero) || numero <= 0){
        resp.innerHTML = ("é necessário informar quantas questões o simulado deve conter");
    } else {
        form.submit();
    }
});
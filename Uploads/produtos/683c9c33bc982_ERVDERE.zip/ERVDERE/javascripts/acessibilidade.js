let fontSize = 16;

const acessibilidadeBtn = document.getElementById('acessibilidadeBtn');
const ddMenu = document.getElementById('ddMenu');
const aumentarFonteBtn = document.getElementById('aumentarFonte');
const diminuirFonteBtn = document.getElementById('diminuirFonte');

acessibilidadeBtn.addEventListener('click', function() {
    ddMenu.style.display = ddMenu.style.display === 'block' ? 'none' : 'block';
});

aumentarFonteBtn.addEventListener('click', function() {
    fontSize += 2;
    document.body.style.fontSize = fontSize + 'px';
    ddMenu.style.display = 'none';
});

diminuirFonteBtn.addEventListener('click', function() {
    fontSize -= 2;
    document.body.style.fontSize = fontSize + 'px';
    ddMenu.style.display = 'none';
});

window.addEventListener('click', function(event) {
    if (!event.target.matches('#acessibilidadeBtn') && !event.target.matches('.dd-content button')) {
        ddMenu.style.display = 'none';
    }
});
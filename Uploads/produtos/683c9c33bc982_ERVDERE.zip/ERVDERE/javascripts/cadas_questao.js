const titulo = document.getElementById("titulo");
const img = document.getElementById("img");
const enunciado = document.getElementById("enunciado");
const assunto = document.getElementById("assunto");
const alt1 = document.getElementById("alt1");
const alt2 = document.getElementById("alt2");
const alt3 = document.getElementById("alt3");
const alt4 = document.getElementById("alt4");
const alt5 = document.getElementById("alt5");
const opt1 = document.getElementById("1");
const opt2 = document.getElementById("2");
const opt3 = document.getElementById("3");
const opt4 = document.getElementById("4");
const opt5 = document.getElementById("5");
const resposta = document.getElementById("resp");

function cadastrar_questao(){
    if (enunciado.value === "" ) {
        alert("A questão deve ter um enunciado");
    } else if (assunto.value === "0") {
        alert("É necessário vincular a questão a um assunto");
    } else if (!(opt1.checked || opt2.checked || opt3.checked || 
                opt4.checked || opt5.checked)) {
        alert("É necessário informar qual alternativa é a verdadeira");            
    } else {
        let dados = new FormData();
        dados.append("titulo", titulo.value);
        dados.append("img", img.files[0]);
        dados.append("enunciado", enunciado.value);
        dados.append("assunto", assunto.value);
        dados.append("alt1", alt1.value);
        dados.append("alt2", alt2.value);
        dados.append("alt3", alt3.value);
        dados.append("alt4", alt4.value);
        dados.append("alt5", alt5.value);

        if (opt1.checked) {
            dados.append("verdadeira", alt1.value);
        } else if (opt2.checked) {
            dados.append("verdadeira", alt2.value);
        } else if (opt3.checked) {
            dados.append("verdadeira", alt3.value);
        } else if (opt4.checked) {
            dados.append("verdadeira", alt4.value);
        } else if (opt5.checked) {
            dados.append("verdadeira", alt5.value);
        }

        fetch("http://localhost/ERVDERE/server_scripts/processa_questao.php", {
            method: "POST",
            body: dados
        }).then(resp => { return resp.text() }).then(resp => {
            resposta.innerHTML = resp;
            setTimeout(() => {
                window.location.href = "http://localhost/ERVDERE/cadas_questao.php";
            } , 2000)
            
        });
    }
}

function postar(){
    const form = document.getElementById("form");
    const titulo = document.getElementById("title").value;
    const video = document.getElementById("subject");
    if (titulo !== ""){
        form.submit();
    }
}
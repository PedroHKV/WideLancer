function new_materia(){
    const form = document.getElementById("form");
    const nome = document.getElementById("input").value;
    const professor = document.getElementById("select").value;
    let resp = document.getElementById("resp");
    if( nome !== "" && professor != 0){
        form.submit();
    } else if (nome === "") {
        resp.innerHTML = ("é obrigatorio informar o nome da nova matéria");
    } else if (professor == 0) {
        resp.innerHTML = ("escolha um professor para a materia");
    }
}
document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById('canva').getContext('2d');
    let nomes_mats = []
    let notas = []
    materias.forEach(materia => {
        nomes_mats.push(materia[2]);
    });

    results.forEach(resultado => {
        let total_questoes = parseInt(resultado[1]) + parseInt(resultado[2]);
        let acertos = parseInt(resultado[1]);
        let desempenho = 100 *  (acertos/total_questoes);
        notas.push(desempenho);
    })
    console.log(JSON.stringify(notas));
    
    
    const data = {
        labels: nomes_mats,  
        datasets: [{
            label: 'Desempenho do Usuário',
            data: notas,  
            backgroundColor: 'rgba(54, 162, 235, 0.2)',  
            borderColor: 'rgba(54, 162, 235, 1)',       
            borderWidth: 1  
        }]
    };
    const config = {
        type: 'radar',
        data:data,
        options: {
            scales: {
                r: {
                    beginAtZero: true, 
                    max: 100 
                }
            },
            responsive: true, 
            plugins: {
                legend: {
                    position: 'top' 
                }
            }
        }
    };
    const myRadarChart = new Chart(ctx, config);
})

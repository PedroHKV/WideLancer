<?php
include "./server_scripts/modulos/mod1_consultas.php";
include "./server_scripts/modulos/mod2_insercao.php";

session_start();
$usuario = $_SESSION["user"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $destinatario = $_POST["destinatario"];

    $sql = new mysqli("localhost", "root", "", "erudere");

    function obterIdUsuario($sql, $email) {
      $stmt = $sql->prepare("SELECT id FROM usuario WHERE email = ? LIMIT 1");
      $stmt->bind_param("s", $email);
      $stmt->execute();
      $result = $stmt->get_result();
      if ($result->num_rows === 0) {
          return null;
      }
      $usuario = $result->fetch_assoc();
      return intval($usuario['id']);
    }

    $usuario_id = obterIdUsuario($sql, $usuario);

    $resultado = $sql->query("SELECT id FROM usuario WHERE email = '$destinatario'");
    if ($resultado->num_rows > 0) {
        $destinatario_id = $resultado->fetch_assoc()['id'];

        $verificacao = $sql->query("SELECT * FROM solicitacoes_amizade 
                                    WHERE (remetente_id = '$usuario_id' AND destinatario_id = '$destinatario_id')
                                       OR (remetente_id = '$destinatario_id' AND destinatario_id = '$usuario_id')");
        
        if ($verificacao->num_rows == 0) {
            $sql->query("INSERT INTO solicitacoes_amizade (remetente_id, destinatario_id, status)
                         VALUES ('$usuario_id', '$destinatario_id', 'pendente')");
            
            echo json_encode(["status" => "success", "message" => "Solicitação de amizade enviada com sucesso!"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Já existe uma solicitação pendente ou vocês já são amigos."]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "O destinatário não foi encontrado."]);
    }

    $sql->close();
}
?>

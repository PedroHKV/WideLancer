<?php
    //recebe o banco de dados onde a deleção será feita
    //recebe o email do usuário a ser deletado
    //remove o usuário e todas suas associações do sistema
    function deletar_usuario($sql, $email) {
        $sql->query("DELETE FROM usuario WHERE email = '$email'");
    }

    //recebe o banco de dados onde a deleção será feita
    //recebe o id da sede a ser deletada
    //remove a sede e todas suas associações do sistema
    function deletar_sede($sql, $sede_id) {
        $delecao = $sql->prepare("CALL deletar_sede(?)");
        $delecao->bind_param("i", $sede_id);
        $delecao->execute();
        $delecao->close();
    }

    //recebe o banco de dados onde a deleção será feita
    //recebe o email do usuário e o id da sede
    //remove a associação entre o usuário e a sede
    function remover_usuario_sede($sql, $email, $sede_id) {
        $sql->query("DELETE FROM usuario_sedes WHERE usuario_email = '$email' AND sede_id = $sede_id");
    }

    //recebe o banco de dados onde a deleção será feita
    //recebe o id da inscrição a ser deletada
    //remove a inscrição do sistema
    function deletar_inscricao($sql, $email) {
        $sql->query("DELETE FROM inscricoes WHERE usuario = '$email'");
    }

    function recusar_inscricao($sql, $inscricao_id) {
        deletar_inscricao($sql , $inscricao_id);
    }

?>  

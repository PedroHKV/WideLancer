<?php
    // Função para obter o ID do usuário a partir do e-mail
    function obterIdUsuario($sql, $email) {
        $stmt = $sql->prepare("SELECT id FROM usuario WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            return null;
        }
        $usuario = $result->fetch_assoc();
        return intval($usuario['id']);
    }

    // Função para carregar mensagens
    function carregarMensagens($sql, $usuario_email, $amigo_email) {
        $usuario_id = obterIdUsuario($sql, $usuario_email);
        $amigo_id = obterIdUsuario($sql, $amigo_email);

        if ($usuario_id === null || $amigo_id === null) {
            echo "Usuário ou amigo não autenticado.";
            exit;
        }

        // Preparar a consulta para evitar SQL Injection
        $stmt = $sql->prepare("SELECT * FROM mensagem WHERE 
            (remetente_id = ? AND destinatario_id = ?) OR 
            (remetente_id = ? AND destinatario_id = ?) 
            ORDER BY data_msg");
        $stmt->bind_param("iiii", $usuario_id, $amigo_id, $amigo_id, $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();

        while ($mensagem = $result->fetch_assoc()) {
            $autor = ($mensagem['remetente_id'] == $usuario_id) ? 'Você' : 'Amigo';
            echo "<p><strong>" . htmlspecialchars($autor) . ":</strong> " . htmlspecialchars($mensagem['conteudo']) . "</p>";
        }
        $stmt->close();
        exit;
    }

    // Função para enviar mensagem
    function enviarMensagem($sql, $usuario_email) {
        $destinatario_email = isset($_POST['destinatario_email']) ? $_POST['destinatario_email'] : '';
        $mensagem = isset($_POST['mensagem']) ? $sql->real_escape_string($_POST['mensagem']) : '';

        $destinatario_id = obterIdUsuario($sql, $destinatario_email);
        $usuario_id = obterIdUsuario($sql, $usuario_email);

        if ($destinatario_id && !empty($mensagem) && $usuario_id) {
            $sql->query("INSERT INTO mensagem (remetente_id, destinatario_id, conteudo, data_msg) 
                        VALUES ('$usuario_id', '$destinatario_id', '$mensagem', NOW())");
            echo "Mensagem enviada com sucesso.";
        } else {
            echo "Dados inválidos.";
        }
        exit;
    }

    // Função para remover amigo
    function removerAmigo($sql, $usuario_email) {
        $amigo_email = isset($_GET['amigo_email']) ? $_GET['amigo_email'] : '';

        $usuario_id = obterIdUsuario($sql, $usuario_email);
        $amigo_id = obterIdUsuario($sql, $amigo_email);

        if ($amigo_id && $usuario_id) {
            $sql->query("DELETE FROM amigos WHERE 
                (usuario1_id = '$usuario_id' AND usuario2_id = '$amigo_id') OR 
                (usuario2_id = '$usuario_id' AND usuario1_id = '$amigo_id')");
            header("Location: amigos.php");
            exit;
        }
    }

    // Função para enviar solicitação de amizade
    function enviarSolicitacao($sql, $usuario_email) {
        $destinatario_email = isset($_POST['destinatario']) ? $sql->real_escape_string($_POST['destinatario']) : '';

        // Obter ID do destinatário pelo email
        $destinatario_id = obterIdUsuario($sql, $destinatario_email);
        $usuario_id = obterIdUsuario($sql, $usuario_email);

        if ($destinatario_id && $usuario_id) {
            // Verificar se já existe uma solicitação pendente ou amizade existente
            $verificacao = $sql->prepare("SELECT * FROM solicitacoes_amizade 
                                        WHERE remetente_id = ? AND destinatario_id = ?
                                        OR remetente_id = ? AND destinatario_id = ?");
            $verificacao->bind_param("iiii", $usuario_id, $destinatario_id, $destinatario_id, $usuario_id);
            $verificacao->execute();
            $result = $verificacao->get_result();

            if ($result->num_rows === 0) {
                // Inserir a solicitação de amizade no banco de dados
                $sql->query("INSERT INTO solicitacoes_amizade (remetente_id, destinatario_id, status, data_solicitacao)
                            VALUES ('$usuario_id', '$destinatario_id', 'pendente', NOW())");
                echo "Solicitação de amizade enviada.";
            } else {
                echo "Já existe uma solicitação pendente ou vocês já são amigos.";
            }
            $verificacao->close();
        } else {
            echo "Usuário não encontrado.";
        }
        exit;
    }

    function aceitarSolicitacao($sql, $usuario_email) {
        $usuario_id = obterIdUsuario($sql, $usuario_email);
        $remetente_email = $_GET['remetente_email'];
        $remetente_id = obterIdUsuario($sql, $remetente_email);

        if ($usuario_id && $remetente_id) {
            // Atualiza o status da solicitação para aceito
            $stmt = $sql->prepare("UPDATE solicitacoes_amizade SET status = 'aceito' 
                                WHERE remetente_id = ? AND destinatario_id = ?");
            $stmt->bind_param("ii", $remetente_id, $usuario_id);
            $stmt->execute();

            // Adiciona na tabela de amigos
            $stmt = $sql->prepare("INSERT INTO amigos (usuario1_id, usuario2_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $remetente_id, $usuario_id);
            $stmt->execute();

            header("Location: amigos.php");
            exit;
        }
    }

    function recusarSolicitacao($sql, $usuario_email) {
        $usuario_id = obterIdUsuario($sql, $usuario_email);
        $remetente_email = $_GET['remetente_email'];
        $remetente_id = obterIdUsuario($sql, $remetente_email);

        if ($usuario_id && $remetente_id) {
            $stmt = $sql->prepare("DELETE FROM solicitacoes_amizade 
                                WHERE remetente_id = ? AND destinatario_id = ?");
            $stmt->bind_param("ii", $remetente_id, $usuario_id);
            $stmt->execute();

            header("Location: amigos.php");
            exit;
        }
    }

    function pendentes($sql , $usuario_id){
        $pendentes = $sql->query("SELECT sa.*, u.email AS remetente_email  FROM solicitacoes_amizade sa JOIN usuario u ON sa.remetente_id = u.id WHERE sa.destinatario_id = '$usuario_id' AND sa.status = 'pendente'");
        return $pendentes;
    }

    function amigos($sql , $usuario_id){
        $amigos = $sql->query("SELECT u.email, u.nome, u.foto_perfil FROM amigos AS a JOIN usuario AS u ON (a.usuario1_id = '$usuario_id' AND a.usuario2_id = u.id) OR (a.usuario2_id = '$usuario_id' AND a.usuario1_id = u.id)");
        return $amigos;
    }


?>
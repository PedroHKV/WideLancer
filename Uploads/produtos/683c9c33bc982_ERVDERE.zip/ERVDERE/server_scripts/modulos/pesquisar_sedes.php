<?php
include "./database.php"; // Inclua seu arquivo de conexão com o banco de dados

if (isset($_GET['query'])) {
    $query = $_GET['query'];
    $sql = "SELECT * FROM sedes WHERE nome LIKE ?"; // Supondo que a tabela se chama 'sedes' e a coluna 'nome'
    $stmt = $conn->prepare($sql);
    $searchTerm = "%$query%";
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sedes = [];
    while ($row = $result->fetch_assoc()) {
        $sedes[] = $row;
    }
    
    echo json_encode($sedes);
}
?>

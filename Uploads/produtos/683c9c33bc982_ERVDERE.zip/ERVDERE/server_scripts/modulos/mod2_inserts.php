<?php
    //recebe o banco de dados onde a incerção será feita
    //insere os dados do usuário na tabela usuário
    function cadastrar($sql , $nome , $email , $senha_input){
        $incercao = $sql->prepare("CALL cadas_user(?, ?, ?)");
        $incercao->bind_param("sss", $nome, $email, $senha_input);
        $incercao->execute();
        $incercao->close();
    }


    //recebe o banco de dados onde a sede será criada
    //recebe os dados da sede e o id do criador da sede dentro do banco de dados
    //insere  o nome , cidade , rua e objetivo da sede na tabela de sede
    //define o criador da sede como curador
    function criar_sede($sql ,$curador, $nome , $cidade , $rua , $obj){
        $incercao = $sql->prepare("CALL criar_sede(?, ?, ?, ?, ?)");
        $incercao->bind_param("issss", $curador, $nome, $cidade, $rua, $obj);
        $incercao->execute();
        $incercao->close();
    }


    //recebe o banco de dados onde a materia será inserida
    //recebe o nome da materia e o nome do professor que a adiministra
    //insere a nova matéria na tabela de materias associa ela ao professor
    //na tabela professor materia
    //retorna true caso consiga realizar a insercao e false caso contrario
    function cadastro_materia($sql , $sede_id , $materia , $professor){
        try {
            $insercao = $sql->prepare("CALL cadastrar_materia(?, ?, ?)");
            $insercao->bind_param("isi" , $sede_id , $materia , $professor);
            $insercao->execute();
            $insercao->close();
            return true;
        } catch (Exception $excessao) {
            return false;
        }
    }

    //recebe o banco de dados onde será feita a incerção
    // recebe o id da sede 
    //recebe o id da materia onde sera feita a incerção
    //recebe o nome e a importancia do novo assunto
    //insere o assunto no banco de dados da sede 
    // retorna true caso consiga e false caso nao consiga inserir o assunto
    function add_assunto($sql , $materia , $nome , $importancia){
        try {
            $incercao = $sql->query("INSERT INTO assunto(nome , materia_id , importancia) VALUES ('$nome' ,$materia , $importancia);");
            return true;
        } catch (Exception $excessao) {
            return false;
        }
    }

    //recebe o banco de dados onde sera feita a inserção
    //recebe o id do professor que faz o conteudo
    //recebe o id do assunto onde o conteudo é postado
    //recebe o titulo do conteudo
    //recebe a descrição do conteudo
    //recebe o local onde está o video do conteudo
    // insere os dados no banco de dados
    function add_conteudo($sql ,$professor_id , $id_assunto , $titulo , $descricao , $destino){
        $insercao = $sql->prepare("CALL post_conteudo(?, ?, ?, ?, ?)");
        $insercao->bind_param("iisss", $professor_id, $id_assunto, $titulo, $descricao, $destino);
        $insercao->execute();
        $insercao->close();
    }

    //recebe o banco de dados onde sera feita a inserção
    //recebe o id do curador que faz o post
    //recebe o titulo do conteudo
    //recebe a descrição do conteudo
    //recebe o local onde está a imagem do conteudo
    // insere os dados no banco de dados
    function add_feed($sql, $curador_id, $titulo, $texto, $destino) {
        $insercao = $sql->prepare("CALL post_feed(?, ?, ?, ?)");
        $insercao->bind_param("isss", $curador_id, $titulo, $texto, $destino);
        $insercao->execute();
        $insercao->close();
    }

    function add_inscricao($sql, $cargo, $usuario, $data, $sede_id){
        $insercao = $sql->prepare("INSERT INTO inscricoes (cargo, usuario, data, sede_id) VALUES (?, ?, ?, ?)");
        $insercao->bind_param("sssi", $cargo, $usuario, $data, $sede_id);
        $insercao->execute();
        $insercao->close();
    }

    //recebe o banco de dados onde será feita a inserção
    //recebe o id da inscrição
    //recebe o cargo do usuário
    //recebe o id da sede
    //insere o usuário na tabela de usuários da sede
    function add_usuario_sede($sql, $email, $cargo, $sede_id) {
        switch ($cargo) {
            case 'aluno':
                $consulta = $sql->query("SELECT id_aluno FROM id_aluno WHERE email = '$email'");
                $id = (int) $consulta->fetch_assoc()["id_aluno"];
                $query = "INSERT INTO sede_aluno (sede_idsede, id_aluno) VALUES ($sede_id, $id)";
                $sql->query($query);
                break;
            case 'curador':
                $consulta = $sql->query("SELECT id_curad FROM id_curad WHERE email = '$email'");
                $id = (int) $consulta->fetch_assoc()["id_curad"];
                $query = "INSERT INTO sede_curador (sede_id, curador_id) VALUES ($sede_id, $id)";
                $sql->query($query);
                break;
            case 'professor':
                $consulta = $sql->query("SELECT id_prof FROM id_prof WHERE email = '$email'");
                echo $email;
                $id = (int) $consulta->fetch_assoc()["id_prof"];
                $query = "INSERT INTO sede_professor (id_sede, id_professor) VALUES ($sede_id, $id)";
                $sql->query($query);
                break;
            default:
                throw new Exception("Cargo inválido: $cargo");
        }
    }

    //recebe um banco de dados onde será feita a incerssão
    //recebe o id do assunto relacionado a questão
    //recebe o caminho da questão 
    //recebe o enunciado da questão
    //recebe as alternativas da questão na forma de um array numerico
    //recebe a alternativa verdadeira da questão
    //insere os dados na tabela de questão e na tabela de relacionamento
    //da questão com o assunto
    function cadastrar_questao($sql , $assunto_id , $titulo ,$caminho1 , $enunciado , $alts , $verdad){
        $alternativas = implode(", ",$alts);
        $insercao = $sql->prepare("CALL cadas_questao(?, ?, ?, ?, ?, ?)");
        $insercao->bind_param("isssss", $assunto_id, $titulo, $caminho1, $enunciado, $alternativas, $verdad);
        $insercao->execute();
        $insercao->close();
    };

    //recebe um banco de dados onde será feita a inserção
    // recebe um array com as alterantivas do simulado e um valor representando
    //se o usuario acertou ou errou 
    function salvar_resultado($sql, $result, $aluno_id) {
        foreach ($result as &$item) {
            $item[0] = (int)$item[0]; 
            $item[1] = (int)$item[1]; 
        }
        unset($item); 
    
        $resultado_json = json_encode($result); 
    
        
        $query = "CALL save_simul(?, ?)";
    
        if ($stmt = $sql->prepare($query)) {
            
            $stmt->bind_param('is', $aluno_id, $resultado_json);
            $stmt->execute();
    
            if ($stmt->affected_rows > 0) {
            } else {
                echo "Erro ao salvar o resultado.";
            }
    
            $stmt->close();
        } else {
            echo "Erro na preparação da query.";
        }
    }

    function aceitar_inscricao($sql, $user, $cargo, $id) {
        add_usuario_sede($sql , $user, $cargo, $id);
        deletar_inscricao($sql , $user);
    }
?>

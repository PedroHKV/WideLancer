<?php
    //recebe o banco de dados onde a validação será feita
    //verifica se a senha gravada no banco corresponde a senha inserida no campo
    //retorna falso ou verdadeiro
    function validar($sql , $senha_input , $email ) {
        $consulta = $sql->query("SELECT senha FROM usuario WHERE email = '".$email."'");
        $dados_consulta = $consulta->fetch_assoc();
        if ( isset($dados_consulta["senha"]) ){
            if ( $dados_consulta["senha"] === $senha_input ){
                return true;
            } 
        }
        return false;    
    }

    //recebe o banco de dados onde a verificação será feita
    //recebe os dados fornecidos pelo usuario
    //conta quantos usuários possuem o email informado no campo
    //se existem zero usuarios com esse email , retorna false caso contrário retorna true
    function cadastrado($sql , $email ){
        $verificacao = $sql->query("SELECT COUNT(id) AS 'num' FROM usuario WHERE email = '$email'");
        $verif_result = $verificacao->fetch_assoc();
        if ($verif_result["num"] === "0"){
            return false;
        }  else {
            return true;
        }
    }


    //recebe o banco de dados onde a verificação deve ser realizada
    // recebe o nome e endereço da sede
    //verifica se já existe uma sede com o mesmo endereço e nome 
    function isset_sede($sql , $nome ,$rua ,$cidade) {
        $consulta = $sql->query("SELECT COUNT(id) AS 'num' FROM sede WHERE nome = '$nome' AND endereco_rua = '$rua' AND endereco_cidade = '$cidade';");
        $results = $consulta->fetch_assoc();
        if($results["num"] === "0"){
            return true;
        } else {
            return false;
        }
    }

    //recebe um banco de dados
    //recebe um email como parametro
    //retorna o id deste email na tabela usuario dentro do banco de dados
    function id_user( $sql , $email){
        $consulta = $sql->query("SELECT id FROM usuario WHERE email = '$email'");
        $id = (int) $consulta->fetch_assoc()["id"];
        return $id;
    }

    //recebe um banco de dados
    // recebe um email
    //consulta o id de professor referente a esse email na tabela professor
    function id_professor($sql , $email){
        $consulta = $sql->query("SELECT id_prof FROM id_prof WHERE email = '$email'");
        $id_prof = (int) $consulta->fetch_assoc()["id_prof"];
        return $id_prof;
    }

    //recebe o banco de dados onde será feita a consulta
    // recebe um email
    // consulta o id de curador desse email na tabela curador
    function id_curador($sql , $email){
        $consulta = $sql->query("SELECT id_curad FROM id_curad WHERE email = '$email'");
        $id_curad = (int) $consulta->fetch_assoc()["id_curad"];
        return $id_curad;
    }

    //recebe o banco de dados onde será feita a consulta
    // recebe um email
    // consulta o id de aluno desse email na tabela aluno
    function id_aluno( $sql , $email){
        $consulta = $sql->query("SELECT id_aluno FROM id_aluno WHERE email = '$email'");
        $id_curad = (int) $consulta->fetch_assoc()["id_aluno"];
        return $id_curad;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o email do usuario que está na sessão 
    //retorna um array com o nome de todas as sedes em que o usuário faz parte
    function sedes_user($sql , $em_user){
        $consulta = $sql->query("SELECT sede_nome , sede_id FROM usuario_sedes WHERE usuario_email = '$em_user'");
        $results = $consulta->fetch_all();
        return $results;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o email de um usuario
    //retorna o nome desse usuario
    function nome_user($sql , $email){
        $consulta = $sql->query("SELECT nome FROM usuario WHERE email = '".$email."'");
        $nome = $consulta->fetch_assoc()["nome"];
        return $nome;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id do professor na tabela professor
    //retorna o nome do professor
    function nome_professor($sql , $prof_id) {
        $consulta = $sql->query("SELECT professor_nome FROM nome_professor WHERE professor_id = $prof_id");
        $nome = $consulta->fetch_assoc()["professor_nome"];
        return $nome;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id do curador na tabela curador
    //retorna o nome do curador
    function nome_curador($sql , $curad_id){
        $consulta = $sql->query("SELECT usuario_nome FROM nome_curador WHERE curador_id = $curad_id");
        $nome = $consulta->fetch_assoc()["usuario_nome"];
        return $nome;
    }

    //recebe um banco de dados onde sera feita a consulta
    //recebe o id do professor na tabela professor
    //retorna o caminho para a foto de perfil do professor
    //ou o caminho para o icone de perfil caso o professor nao tenha foto
    function foto_professor($sql , $prof_id){
        $consulta = $sql->query("SELECT foto_perfil FROM foto_professor WHERE professor_id = $prof_id");
        $results = $consulta->fetch_assoc();
        if (isset($results)){
            $foto = $results["foto_perfil"];
            return $foto;
        } else {
            return "./imagens/amigo.png";
        }
    }

    //recebe um banco de dados onde sera feita a consulta
    //recebe o id do usuario
    //retorna o caminho para a foto de perfil do usuario
    //ou o caminho para o icone de perfil caso o usuario nao tenha foto
    function foto_usuario($sql , $user_email){
        $consulta = $sql->query("SELECT foto_perfil FROM foto_usuario WHERE usuario_email = '$user_email'");
        $resultado = $consulta->fetch_assoc();
        if (isset($resultado["foto_perfil"])){
            $foto = $resultado["foto_perfil"];
            return $foto;
        } else {
            return "./imagens/amigo.png";
        }
    }

    function senha_usuario($sql , $user){
        $consulta = $sql->query("SELECT senha FROM usuario WHERE email = '$user'");
        $resultado = $consulta->fetch_assoc()["senha"];
        return $resultado;
    }


    //recebe o banco de dados onde será feita a consulta
    //recebe o id de uma sede
    //retorna um array com os nomes dos professores da sede
    function professores_sede($sql , $sede){
        $consulta = $sql->query("SELECT * FROM sede_professores WHERE sede_id = '$sede';");
        $results = $consulta->fetch_all();
        return $results;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id de uma sede
    //retorna um array com os nomes dos curadores da sede
    function curadores_sede($sql , $sede){
        $consulta = $sql->query("SELECT * FROM sede_curadores WHERE sede_id = '$sede';");
        $results = $consulta->fetch_all();
        return $results;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id de uma sede
    //retorna um array com os nomes dos alunos da sede
    function alunos_sede($sql , $sede){
        $consulta = $sql->query("SELECT * FROM sede_alunos WHERE sede_id = '$sede';");
        $results = $consulta->fetch_all();
        return $results;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id de uma sede
    //retorna um array com os nomes de todas as matérias da sede
    function materias_sede($sql , $sede){
        $consulta = $sql->query("SELECT * FROM sede_materias WHERE sede_id = '$sede';");
        $results = $consulta->fetch_all();
        return $results;
    }

    //recebe o banco de dados onde sera realizada a consulta
    //recebe o id de uma materia 
    //retorna o nome da materia dentro do banco 
    function nome_materia($sql , $materia){
        $consulta = $sql->query("SELECT nome FROM materia WHERE id = '$materia'");
        $result = $consulta->fetch_all();
        return $result[0][0];
    }

    //recebe o banco de dados onde sera realizada a consulta
    //recebe o id do assunto dentro do banco
    //retorna o nome do assunto
    function nome_assunto($sql , $assunto){
        $consulta = $sql->query("SELECT nome FROM assunto WHERE id = '$assunto'");
        $result = $consulta->fetch_all();
        return $result[0][0];
    }

    //recebe um banco de dados 
    //recebe um id de uma materia no banco de dados 
    //retorna um array com todos os nomes e os id's dos assuntos da materia
    function assuntos_materia($sql , $id_materia)  {   
        $consulta = $sql->query("SELECT id , nome FROM assunto WHERE materia_id = $id_materia");
        $result = $consulta->fetch_all();
        return $result;
    }

    //recebe um banco de dados 
    //recebe o id de uma sede
    //retorna todos os assuntos cadastrados na sede
    function sede_assuntos($sql , $sede){
        $consulta = $sql->query("SELECT assunto_id , assunto_nome FROM sede_assuntos WHERE sede_id = $sede");
        $resultados = $consulta->fetch_all();
        return $resultados;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id de um assunto no banco de dados
    //retorna um array com todos os posts feitos naquele assunto
    function posts_assunto($sql , $id_assunto){
        $consulta = $sql->query("SELECT * FROM conteudo_assunto WHERE assunto_id = $id_assunto");
        $result = $consulta->fetch_all();
        return $result;
    }

    function sede_posts($sql , $id_sede){
        $consulta = $sql->query("SELECT * FROM sede_posts WHERE sede_id = $id_sede");
        $result = $consulta->fetch_all();
        return $result;
    }

    function todas_sedes($sql) {
        $consulta = $sql->query("SELECT id, nome, descricao FROM sede");
        $results = $consulta->fetch_all(MYSQLI_ASSOC);
        return $results;
    }

    function desc_sede($sql , $id_sede){
        $consulta = $sql->query("SELECT descricao FROM sede WHERE id = $id_sede;");
        $results = $consulta->fetch_assoc()["descricao"];
        return $results;
    }

    //recebe o banco de dados onde será feita a consulta
    //recebe o id da sede
    //retorna um array com todas as inscrições da sede
    function obter_inscricoes($sql, $id) {
      $consulta = $sql->query("SELECT * FROM inscricoes WHERE sede_id = $id");
      return $consulta->fetch_all(MYSQLI_ASSOC);
  }

    // recebe um banco de dados onde será feita a consulta
    // recebe o id de uma sede
    //retorna um array com todas as inscrições da sede
    function cargo( $sql , $id , $email){
        $consulta = $sql->query("SELECT cargo FROM user_funcoes WHERE usuario_email = '$email' AND sede_id = $id ;");
        return $consulta->fetch_assoc()['cargo'];
    }
    
    //recebe um banco de dados onde será feita a consulta
    //recebe um array com os ids dos assuntos que deverao ser abordados no simulado
    //recebe o numero de questões que deverao ser passadas no simulado
    //faz uma consulta no banco de questões
    //embaralha as questões
    //retorna um array numerico de dicionarios com os dados das questões
    function select_questoes($sql, $assuntos, $num) {
        $assuntos_str = implode(",", array_map('intval', $assuntos));
        
        $consulta = $sql->query("SELECT * FROM conteudo_questoes WHERE assunto_id IN ($assuntos_str)ORDER BY RAND()LIMIT $num");
    
        if ($consulta->num_rows > 0) {
            $questoes = [];
            while ($info = $consulta->fetch_assoc()) {
                $alternativas = explode(",", $info['alternativas']);  
                $questoes[] = [
                    $info['titulo'],   
                    $info['imagem'],  
                    $info['enunciado'],   
                    $alternativas,        
                    $info['resposta'],  
                    $info['questao_id'],
                    $info['assunto_id']   
                ];
            }
            return $questoes;
        } else {
            return [];
        }
    }

    function results_simulado($sql , $sede_id , $aluno_id){
        $consulta = $sql->query("SELECT materia_nome , acertos , erros FROM results_simulado WHERE id_sede = $sede_id AND aluno_id = $aluno_id");
        $results = $consulta->fetch_all();
        return $results;
    }
?>

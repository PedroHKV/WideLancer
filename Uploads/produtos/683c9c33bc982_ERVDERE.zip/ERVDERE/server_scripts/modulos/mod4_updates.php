<?php
    //recebe o banco de dados onde a atualização será feita
    //recebe o email do usuário e os novos dados
    //atualiza as informações do usuário
    function atualizar_usuario($sql, $email, $novo_nome, $nova_senha) {
        try {
            $atualizacao = $sql->prepare("UPDATE usuario SET nome = ?, senha = ? WHERE email = ?");
            $atualizacao->bind_param("sss", $novo_nome, $nova_senha , $email);
            $atualizacao->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    //recebe o banco de dados onde a atualização será feita
    //recebe o email do usuario cuja a foto será atualizada
    //insere o endereço da imagem
    function atualizar_foto($sql , $email , $caminho) {
        $atualizacao = $sql->prepare("UPDATE usuario SET foto_perfil = ? WHERE email = ?");
        $atualizacao->bind_param("ss" , $caminho , $email);
        $atualizacao->execute();
    }

    //recebe o banco de dados onde a atualização será feita
    //recebe o id da sede e os novos dados
    //atualiza as informações da sede
    function atualizar_sede($sql, $sede_id, $novo_nome, $nova_cidade, $nova_rua, $novo_obj) {
        $atualizacao = $sql->prepare("UPDATE sede 
            SET nome = ?, 
                endereco_cidade = ?, 
                endereco_rua = ?, 
                objetivo = ? 
            WHERE id = ?");
        $atualizacao->bind_param("ssssi", $novo_nome, $nova_cidade, $nova_rua, $novo_obj, $sede_id);
        $atualizacao->execute();
        $atualizacao->close();
    }

    //recebe o banco de dados onde a atualização será feita
    //recebe o email do usuário, id da sede e novo cargo
    //atualiza o cargo do usuário na sede específica
    function atualizar_cargo_usuario($sql, $email, $sede_id, $novo_cargo) {
        $sql->query("UPDATE usuario_sedes 
            SET cargo = '$novo_cargo' 
            WHERE usuario_email = '$email' 
            AND sede_id = $sede_id");
    }

?>  

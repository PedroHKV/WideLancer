<?php
    include "./modulos/mod2_inserts.php";
    include "./modulos/mod1_consultas.php";
    //pagina para processar as postagens na pagina de assunto
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    $hora = date("Y-m-d H:i:s");
    session_start();
    $curador = $_SESSION["user"];
    $curador_id = id_curador($sql , $curador);
    $titulo = $_POST["titulo"]; 
    $texto = $_POST["texto"]; 
    $img = $_FILES["file"];
    $destino_img = "./imagens_feed/" . preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
    $destino_img2 = "../imagens_feed/" . preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
    move_uploaded_file($img["tmp_name"], $destino_img2);
    add_feed($sql, $curador_id, $titulo, $texto, $destino_img);
    header("Location: http://localhost/ERVDERE/feed.php");
?>
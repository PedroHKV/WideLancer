<?php
    include "./modulos/mod2_inserts.php";
    include "./modulos/mod1_consultas.php";
    //pagina para processar as postagens na pagina de assunto
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    $hora = date("Y-m-d H:i:s");
    session_start();
    $professor = $_SESSION["user"];
    $professor_id = id_professor($sql , $professor);
    $assunto = (int) $_SESSION["id_assunto"];
    //começa a construir o caminho do arquivo recebeido
    $titulo = $_POST["title"]; //vai para o BD
    $descricao = $_POST["subject"]; //vai para o BD
    $video = $_FILES["file"];
    //é necessario tirar os caracteres especiais do arquivo antes de salva-lo
    $destino_vid = "./videos/" . preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($video["name"]));
    // o caminho usado para ler o conteudo é diferente do usado para mover para o diretorio
    $destino_vid2 = "../videos/" . preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($video["name"]));
    //move o video do upload para o destino dentro do servidor
    move_uploaded_file($video["tmp_name"], $destino_vid2);
    add_conteudo($sql ,$professor_id , $assunto , $titulo , $descricao , $destino_vid);
    header("Location: http://localhost/ERVDERE/aulas.php");
?>
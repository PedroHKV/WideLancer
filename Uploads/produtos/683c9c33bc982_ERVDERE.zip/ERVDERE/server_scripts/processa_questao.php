<?php
    include "./modulos/mod1_consultas.php";
    include "./modulos/mod2_inserts.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $titulo = $_POST["titulo"];
        if ( isset($_FILES["img"])){
            $img = $_FILES["img"];
            $caminho1 = "./imgs_questoes/".preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
            $caminho2 = "../imgs_questoes/".preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
            move_uploaded_file($img["tmp_name"], $caminho2);
        } else {
            $caminho1 = "sem img";
        }
        $enunciado = $_POST["enunciado"];
        $assunto_id = $_POST["assunto"];
        $alt1 = $_POST["alt1"];
        $alt2 = $_POST["alt2"];
        $alt3 = $_POST["alt3"];
        $alt4 = $_POST["alt4"];
        $alt5 = $_POST["alt5"];
        $alts = [$alt1 ,$alt2 ,$alt3 ,$alt4 ,$alt5];
        $verdad = $_POST["verdadeira"];
        cadastrar_questao($sql , $assunto_id , $titulo ,$caminho1 , $enunciado , $alts , $verdad);
        echo "questão cadastrada com sucesso";
        
    }
?>
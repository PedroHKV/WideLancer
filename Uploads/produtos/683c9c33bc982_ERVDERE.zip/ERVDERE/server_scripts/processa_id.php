<?php
//Esta pagina tem o objetivo de armazenar na sessão o id da sede acessada pelo
//usuario , sem que ele tenha acesso, via GET , a essa informação 
    if(isset($_GET["id"])){
        $id = $_GET["id"];
        session_start();
        $_SESSION["id_sede"] = $id;
        header("Location: http://localhost/ERVDERE/sede.php");
    }
?>
<?php
    //pagina para tentar inserir os dados de um usuario 
    include "./modulos/mod2_inserts.php";
    include "./modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    $email = $_POST["email"];
    $senha_input = $_POST["password"];
    $nome = $_POST["name"];
    $nao_cadastrado = !cadastrado($sql ,  $email );
    if ($nao_cadastrado){
        cadastrar($sql , $nome , $email , $senha_input);
    } 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            display:flex;
            align-items:center;
            justify-content:center;
            height: 100vh;
        }

        #aviso{
            display: flex ;
            flex-direction:column;
            border:1px solid black;
            width: 50vw;
            height:50vh;
            border-radius:10px;
            color:white;
            background-color:#4C127F;
            align-items:center;
            justify-content:space-around;
        }

        #aviso a {
            text-decoration:none;
            color:white;
            background-color:#673AB7;
            width: 20vw;
            height: 32px;
            display: flex;
            align-items:center;
            justify-content:center;
            border-radius:5px;
            transition:0.3s ease;
        }

        #aviso a:hover{
            transform: scale(1.05);
            border:1px solid white;
        }
    </style>
</head>
<body>
    <div id = "aviso">
        <h1>
            <?php
                if($nao_cadastrado){
                    echo "<h1>usuário cadastrado com sucesso!</h1>";
                } else {
                    echo "<h1>este email já está em uso</h1>";
                }

                $sql->close();
            ?>
        </h1>
        <a href="http://localhost/ERVDERE/login.html">voltar a pagina de login</a>
    </div>
</body>
</html>
<?php
    //pagina para armazenar o id do assunto acessado em uma sessão
    session_start();
    if (isset($_GET['id_assunt'])){
        $assunto_id = $_GET['id_assunt'];
        $_SESSION["id_assunto"] = $assunto_id;
        header("Location: http://localhost/ERVDERE/aulas.php");
    }
?>
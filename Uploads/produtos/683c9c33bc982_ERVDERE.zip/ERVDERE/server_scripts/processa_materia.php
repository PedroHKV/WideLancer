<?php
    //pagina para processamento do id de uma materia
    if (isset($_GET["id_mat"])){
        session_start();
        $id = $_GET["id_mat"];
        $_SESSION["id_mat"] = $id;
        header("Location: http://localhost/ERVDERE/página_matéria.php");
    }
?>
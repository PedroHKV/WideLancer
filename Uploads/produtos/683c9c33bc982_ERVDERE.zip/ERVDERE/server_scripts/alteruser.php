<?php
    include "./modulos/mod1_consultas.php";
    include "./modulos/mod4_updates.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    if ($_SERVER["REQUEST_METHOD"] === "GET"){
        try {
            $nome = $_GET["nome"];
            $senha = $_GET["senha"];
            $atualizado = atualizar_usuario($sql , $user , $nome , $senha);
            echo "dados alterados com sucesso";
        } catch ( Exception $e) {
            echo "erro ao salvar alterações";
        }
    } elseif ( !isset($_FILES["perfil"])) {
        echo "selecione uma imagem para alterar a foto de perfil ";
    } else {
        try{
            $img = $_FILES["perfil"];
            $destino1 = "./perfis/".preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
            $destino2 = "../perfis/".preg_replace("/[^a-zA-Z0-9\._-]/", "_", basename($img["name"]));
            move_uploaded_file($img["tmp_name"] , $destino2);
            atualizar_foto($sql , $user , $destino1);
            echo "foto de perfil alterada com sucesso";
        } catch (Exception $e){
            echo "erro ao salvar alteração";
        }
    }
?>

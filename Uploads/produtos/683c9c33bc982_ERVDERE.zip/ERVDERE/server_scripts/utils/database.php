<?php

function handleDbError($connection, $query) {
    $timestamp = date('Y-m-d H:i:s');
    $errorDetails = [
        'timestamp' => $timestamp,
        'error' => $connection->error,
        'query' => $query
    ];
    
    $logMessage = json_encode($errorDetails) . "\n";
    $logFile = "logs/db_errors.log";
    
    if (!is_dir(dirname($logFile))) {
        mkdir(dirname($logFile), 0755, true);
    }
    
    error_log($logMessage, 3, $logFile);
} 

?>

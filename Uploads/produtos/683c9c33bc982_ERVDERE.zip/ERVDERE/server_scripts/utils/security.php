<?php

function generateToken($length = 32) {
    try {
        return bin2hex(random_bytes($length / 2));  // dividido por 2 pois bin2hex dobra o tamanho
    } catch (Exception $e) {
        error_log("Erro ao gerar token: " . $e->getMessage());
        return false;
    }
} 

?>

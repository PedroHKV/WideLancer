<?php

function redirect($url, $message = '') {
    if ($message) {
        $_SESSION['message'] = $message;
    }
    header("Location: $url");
    exit();
} 

?>

<?php

function isValidEmail($email) {
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validatePassword($password) {
    $requirements = [
        [
            'regex' => '/^.{8,}$/',
            'message' => 'A senha deve ter pelo menos 8 caracteres'
        ],
        [
            'regex' => '/[A-Z]/',
            'message' => 'A senha deve conter pelo menos uma letra maiúscula'
        ],
        [
            'regex' => '/[0-9]/',
            'message' => 'A senha deve conter pelo menos um número'
        ],
        [
            'regex' => '/[!@#$%^&*()\-_=+{};:,<.>]/',
            'message' => 'A senha deve conter pelo menos um caractere especial'
        ]
    ];
    
    foreach ($requirements as $requirement) {
        if (!preg_match($requirement['regex'], $password)) {
            return [
                'valid' => false,
                'message' => $requirement['message']
            ];
        }
    }
    
    return ['valid' => true, 'message' => ''];
} 

?>

<?php
    include "./modulos/mod1_consultas.php";
    include "./modulos/mod2_inserts.php";
    
    $sql = new mysqli("localhost", "root", "", "erudere");
    session_start();
    $id = $_SESSION["id_sede"];
    $user = $_SESSION["user"];
    $aluno_id = id_aluno($sql, $user);
    
    $resultado = json_decode(file_get_contents("php://input"), true);
    
    if (isset($resultado['result'])) {
        $result_simul = $resultado['result'];
        salvar_resultado($sql, $result_simul, $aluno_id); 
        echo "dados_recebidos";
    } else {
        echo json_encode(["status" => "erro", "message" => "Dados inválidos"]);
    }
?>
<?php
    //pagina para processar os dados inseridos para a criação de uma sede
    include "./modulos/mod1_consultas.php";
    include "./modulos/mod2_inserts.php";
    //inicia conexão com banco de dados
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    //recebe variaveis de form_sedes.html
    $nome_sede = $_POST["nome"];
    $cidade = $_POST["cidade"];
    $rua = $_POST["endereco"];
    $obj = $_POST["obj"];
    //verifica o id de quem está tentando criar sede
    session_start();
    $curador1 = $_SESSION["user"];
    $curadorid = id_user($sql , $curador1);
    //verifica se a sede já existe
    $notsede_existe = isset_sede($sql , $nome_sede ,$rua ,$cidade);
    if ($notsede_existe){
        criar_sede($sql ,$curadorid, $nome_sede , $cidade , $rua , $obj);
    } 

    
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            display:flex;
            align-items:center;
            justify-content:center;
            height: 100vh;
        }

        #aviso{
            display: flex ;
            flex-direction:column;
            border:1px solid black;
            width: 50vw;
            height:50vh;
            border-radius:10px;
            color:white;
            background-color:#4C127F;
            align-items:center;
            justify-content:space-around;
        }

        #aviso a {
            text-decoration:none;
            color:white;
            background-color:#673AB7;
            width: 20vw;
            height: 32px;
            display: flex;
            align-items:center;
            justify-content:center;
            border-radius:5px;
            transition:0.3s ease;
        }

        #aviso a:hover{
            transform: scale(1.05);
            border:1px solid white;
        }
    </style>
</head>
<body>
    <div id = "aviso">
        <h1>
            <?php
                if ($notsede_existe) {
                    echo "sede criada com sucesso";
                } else {
                    echo "a sede já existe";
                }
            ?>
        </h1>
        <a href="http://localhost/ERVDERE/sedes.php">voltar a pagina de sedes</a>
    </div>
</body>
</html>
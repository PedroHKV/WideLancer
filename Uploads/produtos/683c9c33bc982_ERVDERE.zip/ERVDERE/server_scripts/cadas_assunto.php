<?php
    include "./modulos/mod2_inserts.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $id_mat = $_SESSION["id_mat"];
    $id_sede = $_SESSION["id_sede"];
    if ( isset($_POST["nome"]) && isset($_POST["importancia"]) ){
        $nome = $_POST["nome"];
        $importancia = $_POST["importancia"];
        $nao_adicionado = add_assunto($sql , $id_mat , $nome , $importancia);
        header("Location: http://localhost/ERVDERE/página_matéria.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            display:flex;
            align-items:center;
            justify-content:center;
            height: 100vh;
        }

        #aviso{
            display: flex ;
            flex-direction:column;
            border:1px solid black;
            width: 50vw;
            height:50vh;
            border-radius:10px;
            color:white;
            background-color:#4C127F;
            align-items:center;
            justify-content:space-around;
        }

        #aviso a {
            text-decoration:none;
            color:white;
            background-color:#673AB7;
            width: 20vw;
            height: 32px;
            display: flex;
            align-items:center;
            justify-content:center;
            border-radius:5px;
            transition:0.3s ease;
        }

        #aviso a:hover{
            transform: scale(1.05);
            border:1px solid white;
        }
    </style>
</head>
<body>
    <div id = "aviso">
        <h1>
            <?php
                if($nao_adicionado){
                    echo "<h1>erro ao inserir assunto</h1>";
                } else {
                    echo "<h1>assunto inserido com sucesso</h1>";
                }

                $sql->close();
            ?>
        </h1>
        <a href="http://localhost/ERVDERE/página_matéria.php">voltar a pagina de matéria</a>
    </div>
</body>
</html>
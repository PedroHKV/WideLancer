<?php
    include "./server_scripts/modulos/mod1_consultas.php";
    $sql = new mysqli("localhost" , "root" , "" , "erudere");
    session_start();
    $user = $_SESSION["user"];
    $nome_user = nome_user($sql , $user);
    $user_foto = foto_usuario($sql , $user);
    $sedes = sedes_user($sql , $user);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERVDERE/sedes</title>
    <link rel="stylesheet" href="./css's/index.css">
    <link rel="stylesheet" href="./css's/sedes.css">
</head>
<body>
    <header>
        <div id="logo">
            <img src="./imagens/Logo Erudere_processed.jpg" alt="Logo" class="logo">
        </div>
        <div id="resto">
            <div id="pesquisa">
                <input type="text" placeholder="Pesquisar...">
            </div>
            <div id="user">
                <div id="acessbilidade">
                    <img src="./imagens/icone_de_acessbilidade_processed.png">
                </div>
                <div id="usuario">
                <a id="user_log" href="./consulta_perfil.php"><img src=<?php echo $user_foto ; ?> alt="Foto do usuário"></a>
                    <span><?php echo $nome_user;?></span>
                </div>
            </div>
        </div>
    </header>
    <div id="lateral">
        <a href=""> Página de Sedes</a>
        <a href="./sedes_lista.php">Ver todas as sedes</a>
        <a href="./form_sedes.php">Criar sede</a>
        <a href="./amigos.php">Amigos</a>
        <a href="./login.html">sair</a>
    </div>
    <div id="pagina">
        <br><h1>SEUS CURSOS</h1>
        <div id="fundo">
             <div id="lista">

                <?php
                    foreach ($sedes as $sede) {
                        echo "<br><a href='http://localhost/ERVDERE/server_scripts/processa_id.php?id=".$sede[1]."' class='sede'>".
                        "<p>".(string) $sede[0]."</p>".
                        "</a>";
                    }
                ?>
                
            </div>
        </div>
    </div>
    
</body>
</html>
